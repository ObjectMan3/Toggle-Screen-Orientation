package a.a.a;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.List;

public class c {
    public static String[] a = new String[]{"sun_", "mon_", "tue_", "wed_", "thu_", "fri_", "sat_"};

    public static List a(Context context) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        List arrayList = new ArrayList();
        try {
            for (ResolveInfo resolveInfo : packageManager.queryIntentActivities(intent, 0)) {
                arrayList.add(resolveInfo.activityInfo.packageName);
            }
            return arrayList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
