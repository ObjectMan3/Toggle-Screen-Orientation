package a.a.a;

import android.content.Context;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;

public class a {
    private static WakeLock a;

    public static void a() {
        if (a != null) {
            a.release();
            a = null;
        }
    }

    public static void a(Context context, String str) {
        if (a == null) {
            a = ((PowerManager) context.getSystemService("power")).newWakeLock(1, str);
            a.acquire();
        }
    }
}
