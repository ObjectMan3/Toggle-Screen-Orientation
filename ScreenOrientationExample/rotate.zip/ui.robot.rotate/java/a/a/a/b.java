package a.a.a;

import java.util.regex.Pattern;

public class b {
    public static int a() {
        StackTraceElement[] stackTrace = new Throwable().getStackTrace();
        return (stackTrace.length > 0 && stackTrace.length >= 2) ? stackTrace[1].getLineNumber() : -1;
    }

    public static String a(Object obj) {
        return new StringBuilder(String.valueOf(Pattern.compile("\\$.*").matcher(obj.getClass().toString().substring(6)).replaceAll(""))).append(".java:").toString();
    }
}
