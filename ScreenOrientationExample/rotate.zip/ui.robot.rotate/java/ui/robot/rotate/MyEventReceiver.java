package ui.robot.rotate;

import android.content.BroadcastReceiver;
import android.content.SharedPreferences;

public class MyEventReceiver extends BroadcastReceiver {
    private SharedPreferences a;
    private z b = new z();

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onReceive(android.content.Context r5, android.content.Intent r6) {
        /*
        r4 = this;
        r0 = android.preference.PreferenceManager.getDefaultSharedPreferences(r5);	 Catch:{ Exception -> 0x006b }
        r4.a = r0;	 Catch:{ Exception -> 0x006b }
        r0 = r4.a;	 Catch:{ Exception -> 0x006b }
        r1 = r4.b;	 Catch:{ Exception -> 0x006b }
        ui.robot.rotate.MyService.a(r0, r1, r5);	 Catch:{ Exception -> 0x006b }
        r0 = r6.getAction();	 Catch:{ Exception -> 0x006b }
        if (r0 == 0) goto L_0x0032;
    L_0x0013:
        r1 = "android.intent.action.BOOT_COMPLETED";
        r1 = r0.equals(r1);	 Catch:{ Exception -> 0x006b }
        if (r1 == 0) goto L_0x0032;
    L_0x001b:
        r1 = r4.b;	 Catch:{ Exception -> 0x006f }
        r1 = r1.d;	 Catch:{ Exception -> 0x006f }
        if (r1 == 0) goto L_0x0032;
    L_0x0021:
        r1 = new android.content.Intent;	 Catch:{ Exception -> 0x006f }
        r2 = ui.robot.rotate.MyService.class;
        r1.<init>(r5, r2);	 Catch:{ Exception -> 0x006f }
        r2 = "id";
        r3 = "start";
        r1.putExtra(r2, r3);	 Catch:{ Exception -> 0x006f }
        r5.startService(r1);	 Catch:{ Exception -> 0x006f }
    L_0x0032:
        if (r0 == 0) goto L_0x003c;
    L_0x0034:
        r1 = "android.intent.action.USER_PRESENT";
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x006b }
        if (r0 == 0) goto L_0x003c;
    L_0x003c:
        r0 = r6.getExtras();	 Catch:{ Exception -> 0x006b }
        if (r0 == 0) goto L_0x006a;
    L_0x0042:
        r1 = "state";
        r0 = r0.getString(r1);	 Catch:{ Exception -> 0x006b }
        r0 = java.lang.String.valueOf(r0);	 Catch:{ Exception -> 0x006b }
        r1 = "alarm";
        r0 = r0.equals(r1);	 Catch:{ Exception -> 0x006b }
        if (r0 == 0) goto L_0x006a;
    L_0x0054:
        r0 = "rotate";
        a.a.a.a.a(r5, r0);	 Catch:{ Exception -> 0x006d }
        r0 = new android.content.Intent;	 Catch:{ Exception -> 0x006d }
        r1 = ui.robot.rotate.MyService.class;
        r0.<init>(r5, r1);	 Catch:{ Exception -> 0x006d }
        r1 = "id";
        r2 = "update";
        r0.putExtra(r1, r2);	 Catch:{ Exception -> 0x006d }
        r5.startService(r0);	 Catch:{ Exception -> 0x006d }
    L_0x006a:
        return;
    L_0x006b:
        r0 = move-exception;
        goto L_0x006a;
    L_0x006d:
        r0 = move-exception;
        goto L_0x006a;
    L_0x006f:
        r1 = move-exception;
        goto L_0x0032;
        */
        throw new UnsupportedOperationException("Method not decompiled: ui.robot.rotate.MyEventReceiver.onReceive(android.content.Context, android.content.Intent):void");
    }
}
