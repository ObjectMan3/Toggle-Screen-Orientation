package ui.robot.rotate;

enum aa {
    ADAPTIVE,
    FL,
    FP,
    FRP,
    FRL,
    AUTO,
    STOCK_AUTO,
    STOCK_MANUAL,
    INIT,
    DISABLE
}
