package ui.robot.rotate;

class r implements Runnable {
    final /* synthetic */ MyService a;

    r(MyService myService) {
        this.a = myService;
    }

    public void run() {
        try {
            String a = this.a.a(this.a.L);
            if (!this.a.h.equalsIgnoreCase(a)) {
                this.a.h = a;
                aa a2 = this.a.a(this.a.b, a, MyService.a, "rotate");
                aa aaVar = this.a.f.c;
                if (a2 == null) {
                    if (!this.a.i.equals(aaVar)) {
                        this.a.a(aaVar, true);
                    }
                    this.a.i = aaVar;
                } else {
                    if (!this.a.i.equals(a2)) {
                        this.a.a(a2, true);
                    }
                    this.a.i = a2;
                }
            }
            this.a.t.postDelayed(this, 120);
        } catch (Exception e) {
        }
    }
}
