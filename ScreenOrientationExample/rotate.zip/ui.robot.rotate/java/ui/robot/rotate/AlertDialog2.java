package ui.robot.rotate;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class AlertDialog2 extends Activity {
    private static String c = "ui.robot.rotate";
    private static String d = "ui.robot.rotatedonate";
    Builder a;
    private AlertDialog b;

    static void a(String str, Context context) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", str, null));
        intent.addFlags(268435456);
        if (context.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
            context.startActivity(intent);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.a = new Builder(this);
        this.a.setIcon(2130837504).setTitle(2131034112).setMessage(2131034135).setPositiveButton("Yes", new f(this)).setNegativeButton("Cancel", new g(this));
        this.b = this.a.create();
        this.b.show();
    }

    protected void onPause() {
        try {
            super.onPause();
            this.b.dismiss();
            finish();
        } catch (Exception e) {
        }
    }
}
