package ui.robot.rotate;

class ah implements Runnable {
    final /* synthetic */ SettingActivity a;

    ah(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void run() {
        this.a.b.removeCallbacks(this.a.d);
        this.a.b.postDelayed(this.a.d, 1000);
        this.a.p.a(17, 2, this.a.f, 24);
    }
}
