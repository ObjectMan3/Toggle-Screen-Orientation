package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

class ad implements OnClickListener {
    final /* synthetic */ ServiceDialog a;

    ad(ServiceDialog serviceDialog) {
        this.a = serviceDialog;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.a.startActivityForResult(new Intent(this.a.b, SettingActivity.class), 2);
    }
}
