package ui.robot.rotate;

import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

class ai implements OnSeekBarChangeListener {
    final /* synthetic */ SettingActivity a;

    ai(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        int i2 = i + 50;
        if (Math.abs(this.a.t - i2) > 10) {
            this.a.p.a();
            this.a.f = i2;
            this.a.c.removeCallbacks(this.a.e);
            this.a.c.postDelayed(this.a.e, 100);
            this.a.a.b = i2;
            this.a.t = i2;
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        this.a.p.a();
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
