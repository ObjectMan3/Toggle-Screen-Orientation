package ui.robot.rotate;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import java.util.Collections;
import java.util.List;

class l implements Runnable {
    final /* synthetic */ AppList a;

    l(AppList appList) {
        this.a = appList;
    }

    public void run() {
        try {
            this.a.f.sendEmptyMessage(3);
            Intent intent = new Intent("android.intent.action.MAIN", null);
            intent.addCategory("android.intent.category.LAUNCHER");
            List<ResolveInfo> queryIntentActivities = this.a.getPackageManager().queryIntentActivities(intent, 0);
            this.a.c.clear();
            Collections.sort(queryIntentActivities, new m(this));
            for (ResolveInfo resolveInfo : queryIntentActivities) {
                if (!this.a.a(resolveInfo.activityInfo.packageName)) {
                    this.a.c.add(new o(resolveInfo.activityInfo, null, null, "", (aa) q.a().get(resolveInfo.activityInfo.packageName)));
                }
            }
            Collections.sort(this.a.c, new n(this));
            this.a.f.sendEmptyMessage(6);
            this.a.f.sendEmptyMessage(2);
        } catch (Exception e) {
        }
    }
}
