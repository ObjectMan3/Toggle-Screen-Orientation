package ui.robot.rotate;

import java.util.Comparator;

class n implements Comparator {
    final /* synthetic */ l a;

    n(l lVar) {
        this.a = lVar;
    }

    public int a(o oVar, o oVar2) {
        return (oVar2.e == null ? "" : oVar2.e.toString().toLowerCase()).compareTo(oVar.e == null ? "" : oVar.e.toString().toLowerCase());
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return a((o) obj, (o) obj2);
    }
}
