package ui.robot.rotate;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class am implements OnCheckedChangeListener {
    final /* synthetic */ SettingActivity a;

    am(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        this.a.a.d = z;
    }
}
