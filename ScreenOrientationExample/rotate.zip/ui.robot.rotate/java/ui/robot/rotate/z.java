package ui.robot.rotate;

import android.view.WindowManager.LayoutParams;

public class z {
    boolean a;
    int b;
    aa c;
    boolean d;
    boolean e;
    boolean f;
    boolean g;
    boolean h;
    boolean i;
    LayoutParams j;

    public z() {
        this.a = false;
        this.b = 130;
        this.d = false;
        this.e = true;
        this.f = true;
        this.g = true;
        this.h = false;
        this.i = true;
        this.j = new LayoutParams();
        this.j.screenOrientation = 2;
    }
}
