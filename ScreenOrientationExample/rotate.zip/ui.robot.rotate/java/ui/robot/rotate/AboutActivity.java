package ui.robot.rotate;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

public class AboutActivity extends Activity {
    private Context a;

    static String a(PackageManager packageManager, String str) {
        String str2 = null;
        try {
            str2 = packageManager.getPackageInfo(str, 0).versionName;
        } catch (NameNotFoundException e) {
        }
        return str2 == null ? "" : str2;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.a = getApplicationContext();
        setContentView(2130903046);
        ScrollView scrollView = (ScrollView) findViewById(2131230746);
        TextView textView = (TextView) findViewById(2131230747);
        textView.setText(Html.fromHtml(getString(2131034132, new Object[]{a(getPackageManager(), getPackageName()), a(getPackageManager(), getPackageName())})));
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        ((Button) findViewById(2131230750)).setOnClickListener(new a(this));
        ((Button) findViewById(2131230748)).setOnClickListener(new b(this));
        ((Button) findViewById(2131230749)).setOnClickListener(new c(this));
    }
}
