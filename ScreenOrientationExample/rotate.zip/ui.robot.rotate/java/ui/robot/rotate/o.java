package ui.robot.rotate;

import android.content.pm.ActivityInfo;
import android.graphics.drawable.Drawable;

final class o {
    ActivityInfo a;
    String b;
    Drawable c;
    String d;
    aa e;

    public o(ActivityInfo activityInfo, String str, Drawable drawable, String str2, aa aaVar) {
        this.a = activityInfo;
        this.b = str;
        this.c = drawable;
        this.d = str2;
        this.e = aaVar;
    }
}
