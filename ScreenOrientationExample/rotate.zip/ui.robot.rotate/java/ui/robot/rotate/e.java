package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;

class e implements OnClickListener {
    final /* synthetic */ AlertDialog a;

    e(AlertDialog alertDialog) {
        this.a = alertDialog;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("word", "cancel");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        this.a.setResult(-1, intent);
        this.a.finish();
    }
}
