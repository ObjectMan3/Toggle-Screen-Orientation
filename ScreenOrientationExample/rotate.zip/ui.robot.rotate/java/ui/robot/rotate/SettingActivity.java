package ui.robot.rotate;

import a.a.a.b;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.ToggleButton;

public class SettingActivity extends Activity {
    z a = new z();
    Handler b = new Handler();
    Handler c = new Handler();
    protected Runnable d = new ag(this);
    protected Runnable e = new ah(this);
    protected int f;
    private Context g;
    private ToggleButton h;
    private ToggleButton i;
    private ToggleButton j;
    private ToggleButton k;
    private int l;
    private SharedPreferences m;
    private ToggleButton n;
    private SeekBar o;
    private ab p;
    private WindowManager q;
    private boolean r = false;
    private ToggleButton s;
    private int t = 0;

    private void a(SeekBar seekBar) {
        try {
            seekBar.setMax(190);
            seekBar.setProgress(this.a.b - 50);
            seekBar.setOnSeekBarChangeListener(new ai(this));
        } catch (Exception e) {
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        try {
            int keyCode = keyEvent.getKeyCode();
            if (keyEvent.getAction() != 1 || keyCode != 4) {
                if (keyEvent.getAction() == 0 && keyCode == 4) {
                    Log.i("rotate", "at (" + b.a(this) + b.a() + ")" + "[" + this.a.a + "]");
                    this.l = 1;
                    return true;
                }
                return super.dispatchKeyEvent(keyEvent);
            } else if (this.l != 1) {
                return true;
            } else {
                Log.i("rotate", "at (" + b.a(this) + b.a() + ")" + "[" + this.a.a + "]");
                MyService.b(this.m, this.a, this.g);
                if (this.a.a) {
                    Intent intent = new Intent(this, MyService.class);
                    intent.putExtra("id", "start");
                    startService(intent);
                    intent = new Intent();
                    intent.setAction(p.a);
                    intent.putExtra("isVisible", "prefchanged");
                    this.g.sendBroadcast(intent);
                } else {
                    stopService(new Intent(this, MyService.class));
                }
                Bundle bundle = new Bundle();
                bundle.putBoolean("cur.enable", this.a.a);
                Intent intent2 = new Intent();
                intent2.putExtras(bundle);
                setResult(-1, intent2);
                finish();
                return true;
            }
        } catch (Exception e) {
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            this.g = getApplicationContext();
            getPreferences(0);
            q.c().a(PreferenceManager.getDefaultSharedPreferences(this));
            this.m = PreferenceManager.getDefaultSharedPreferences(this.g);
            MyService.a(this.m, this.a, this.g);
            this.a.a = true;
            this.p = new ab(this.g);
            this.q = (WindowManager) getSystemService("window");
            if (!this.r) {
                this.q.addView(this.p, new LayoutParams(2003, 8));
            }
            this.r = true;
            setContentView(2130903042);
            this.o = (SeekBar) findViewById(2131230732);
            this.o.setEnabled(false);
            a(this.o);
            this.h = (ToggleButton) findViewById(2131230726);
            this.h.setOnCheckedChangeListener(new aj(this));
            this.i = (ToggleButton) findViewById(2131230731);
            this.i.setEnabled(false);
            this.i.setOnCheckedChangeListener(new ak(this));
            this.j = (ToggleButton) findViewById(2131230728);
            this.j.setOnCheckedChangeListener(new al(this));
            this.k = (ToggleButton) findViewById(2131230730);
            this.k.setEnabled(false);
            this.s = (ToggleButton) findViewById(2131230727);
            this.s.setOnCheckedChangeListener(new am(this));
            this.n = (ToggleButton) findViewById(2131230733);
            this.n.setEnabled(false);
            this.n.setOnCheckedChangeListener(new an(this));
            Button button = (Button) findViewById(2131230729);
            button.setEnabled(false);
            button.setOnClickListener(new ao(this));
            this.h.setChecked(this.a.a);
            this.i.setChecked(this.a.g);
            this.k.setChecked(this.a.h);
            this.j.setChecked(this.a.i);
            this.s.setChecked(this.a.d);
            this.n.setChecked(this.a.f);
        } catch (Exception e) {
        }
    }

    protected void onDestroy() {
        try {
            super.onDestroy();
            if (this.r) {
                this.q.removeView(this.p);
                this.r = false;
            }
        } catch (Exception e) {
        }
    }

    protected void onPause() {
        super.onPause();
        try {
            if (this.r) {
                this.q.removeView(this.p);
                this.r = false;
            }
        } catch (Exception e) {
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (!this.r) {
                this.q.addView(this.p, new LayoutParams(2003, 8));
                this.r = true;
            }
        } catch (Exception e) {
        }
    }
}
