package ui.robot.rotate;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread.UncaughtExceptionHandler;

class w implements UncaughtExceptionHandler {
    final /* synthetic */ MyService a;

    w(MyService myService) {
        this.a = myService;
    }

    public void uncaughtException(Thread thread, Throwable th) {
        PrintWriter printWriter = new PrintWriter(new StringWriter());
        th.printStackTrace(printWriter);
        printWriter.close();
    }
}
