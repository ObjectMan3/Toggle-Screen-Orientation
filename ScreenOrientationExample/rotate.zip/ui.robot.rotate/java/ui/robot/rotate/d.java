package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;

class d implements OnClickListener {
    final /* synthetic */ AlertDialog a;

    d(AlertDialog alertDialog) {
        this.a = alertDialog;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        AlertDialog.a(AlertDialog.a, this.a);
        Bundle bundle = new Bundle();
        bundle.putString("word", "check");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        this.a.setResult(-1, intent);
        this.a.finish();
    }
}
