package ui.robot.rotate;

import android.content.Intent;

class x implements Runnable {
    final /* synthetic */ MyService a;
    private final /* synthetic */ Intent b;

    x(MyService myService, Intent intent) {
        this.a = myService;
        this.b = intent;
    }

    public void run() {
        this.a.a(this.b);
    }
}
