package ui.robot.rotate;

public class p {
    public static final String a = new StringBuilder(String.valueOf(p.class.getName())).append("_intent").toString();
}
