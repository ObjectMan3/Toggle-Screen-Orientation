package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;

class f implements OnClickListener {
    final /* synthetic */ AlertDialog2 a;

    f(AlertDialog2 alertDialog2) {
        this.a = alertDialog2;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        AlertDialog2.a(AlertDialog2.d, this.a);
        Bundle bundle = new Bundle();
        bundle.putString("word", "check");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        this.a.setResult(-1, intent);
        this.a.finish();
    }
}
