package ui.robot.rotate;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class AlertDialog extends Activity {
    private static String a = "ui.robot.rotate";

    static void a(String str, Context context) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", str, null));
        intent.addFlags(268435456);
        if (context.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
            context.startActivity(intent);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Builder builder = new Builder(this);
        builder.setIcon(2130837504).setTitle(2131034112).setMessage(2131034134).setPositiveButton("Yes", new d(this)).setNegativeButton("Cancel", new e(this)).create();
        builder.show();
    }
}
