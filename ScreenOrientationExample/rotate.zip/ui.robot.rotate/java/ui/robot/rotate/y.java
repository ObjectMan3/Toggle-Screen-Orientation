package ui.robot.rotate;

import android.content.Context;
import android.view.OrientationEventListener;

class y extends OrientationEventListener {
    final /* synthetic */ MyService a;

    public y(MyService myService, Context context) {
        this.a = myService;
        super(context);
    }

    void a() {
        if (!(this.a.E == this.a.C || this.a.B == this.a.C)) {
            this.a.D = this.a.C;
            this.a.s.removeCallbacks(this.a.y);
            if (this.a.z.a) {
                this.a.z.a();
            }
            if (this.a.g == aa.AUTO) {
                this.a.a();
            } else {
                this.a.z.a(17, this.a.C, this.a.f.b, 8);
                this.a.s.postDelayed(this.a.y, (long) this.a.e);
            }
        }
        this.a.B = this.a.C;
    }

    public void onOrientationChanged(int i) {
        if (i != -1 && this.a.g != aa.STOCK_MANUAL && this.a.g != aa.STOCK_AUTO && this.a.g != aa.FL && this.a.g != aa.FP && this.a.g != aa.FRL && this.a.g != aa.FRP && this.a.g != aa.STOCK_AUTO && this.a.g != aa.STOCK_AUTO) {
            MyService myService = this.a;
            myService.A = myService.A + 1;
            if (this.a.A == 1) {
                if (i < 25 || i > 335) {
                    this.a.C = 2;
                    a();
                }
                if (i < 295 && i > 245) {
                    this.a.C = 0;
                    a();
                }
                if (i < 115 && i > 65) {
                    this.a.C = 8;
                    a();
                }
                if (i < 205 && i > 155) {
                    this.a.C = 9;
                    a();
                }
                this.a.A = 0;
            }
        }
    }
}
