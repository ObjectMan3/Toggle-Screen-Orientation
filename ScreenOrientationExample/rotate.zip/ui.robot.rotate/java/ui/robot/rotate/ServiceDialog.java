package ui.robot.rotate;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;

public class ServiceDialog extends Activity {
    private static String g = "ui.robot.rotate";
    private static String h = "ui.robot.rotatedonate";
    z a = new z();
    private Context b;
    private boolean c = true;
    private SharedPreferences d;
    private Builder e;
    private AlertDialog f;

    static boolean a(Context context, String str) {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) context.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (str.equals(runningServiceInfo.service.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    void a() {
        if (a(this.b, h)) {
            startActivityForResult(new Intent(this, AlertDialog2.class), 1);
        } else {
            b();
        }
    }

    void b() {
        q.c().a(PreferenceManager.getDefaultSharedPreferences(this));
        this.d = PreferenceManager.getDefaultSharedPreferences(this.b);
        MyService.a(this.d, this.a, this.b);
        if (this.a.c == aa.DISABLE) {
            this.a.c = aa.ADAPTIVE;
            MyService.b(this.d, this.a, this.b);
        }
        Intent intent = new Intent(this, MyService.class);
        intent.putExtra("id", "start");
        startService(intent);
        try {
            OnClickListener acVar = new ac(this);
            ArrayList arrayList = new ArrayList();
            arrayList.add(getString(2131034116));
            arrayList.add(getString(2131034117));
            arrayList.add(getString(2131034118));
            arrayList.add(getString(2131034119));
            arrayList.add(getString(2131034120));
            arrayList.add(getString(2131034121));
            arrayList.add(getString(2131034122));
            arrayList.add(getString(2131034123));
            arrayList.add(getString(2131034124));
            CharSequence[] charSequenceArr = new CharSequence[arrayList.size()];
            Iterator it = arrayList.iterator();
            int i = 0;
            while (it.hasNext()) {
                charSequenceArr[i] = (String) it.next();
                i++;
            }
            int i2 = this.a.c == aa.ADAPTIVE ? 0 : this.a.c == aa.FL ? 1 : this.a.c == aa.FP ? 2 : this.a.c == aa.FRP ? 3 : this.a.c == aa.FRL ? 4 : this.a.c == aa.AUTO ? 5 : this.a.c == aa.STOCK_AUTO ? 6 : this.a.c == aa.STOCK_MANUAL ? 7 : 8;
            this.e = new Builder(this);
            this.e.setIcon(2130837519);
            this.e.setTitle(getString(2131034125)).setSingleChoiceItems(charSequenceArr, i2, acVar);
            this.e.setPositiveButton(2131034137, new ad(this));
            this.e.setNegativeButton(2131034136, new ae(this));
            this.f = this.e.create();
            this.f.setOnCancelListener(new af(this));
            this.f.show();
        } catch (Exception e) {
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 1 && i2 == -1) {
            String string = intent.getExtras().getString("word");
            if (string != null && string.equalsIgnoreCase("cancel")) {
                finish();
            }
        }
        if (i == 2 && i2 == -1) {
            Boolean valueOf = Boolean.valueOf(intent.getExtras().getBoolean("cur.enable"));
            if (valueOf != null && !valueOf.booleanValue()) {
                finish();
            }
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.b = getApplicationContext();
    }

    protected void onPause() {
        try {
            super.onPause();
            this.f.dismiss();
        } catch (Exception e) {
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            a();
        } catch (Exception e) {
        }
    }
}
