package ui.robot.rotate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

class u extends BroadcastReceiver {
    final /* synthetic */ MyService a;

    u(MyService myService) {
        this.a = myService;
    }

    public void onReceive(Context context, Intent intent) {
        String string = intent.getExtras().getString("isVisible");
        if (string != null) {
            if (string.equalsIgnoreCase("prefchanged")) {
                this.a.j();
            }
            if (string.equalsIgnoreCase("landscape")) {
                z zVar = new z();
                SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(MyService.a);
                MyService.a(defaultSharedPreferences, zVar, MyService.a);
                zVar.c = aa.FL;
                MyService.b(defaultSharedPreferences, zVar, MyService.a);
                this.a.j();
            }
            if (string.equalsIgnoreCase("portrait")) {
                z zVar2 = new z();
                SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(MyService.a);
                MyService.a(defaultSharedPreferences2, zVar2, MyService.a);
                zVar2.c = aa.FP;
                MyService.b(defaultSharedPreferences2, zVar2, MyService.a);
                this.a.j();
            }
        }
    }
}
