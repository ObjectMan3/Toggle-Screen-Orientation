package ui.robot.rotate;

import android.view.View;
import android.view.View.OnClickListener;

class a implements OnClickListener {
    final /* synthetic */ AboutActivity a;

    a(AboutActivity aboutActivity) {
        this.a = aboutActivity;
    }

    public void onClick(View view) {
        this.a.finish();
    }
}
