package ui.robot.rotate;

import android.content.SharedPreferences;
import java.util.LinkedHashMap;
import java.util.Map;

public final class q {
    static LinkedHashMap a;
    private static q b = null;
    private int c = 99;
    private String d = "1";
    private SharedPreferences e;

    private q() {
    }

    public static synchronized Map a() {
        Map map;
        synchronized (q.class) {
            if (a == null) {
                a = new LinkedHashMap();
            }
            map = a;
        }
        return map;
    }

    public static q c() {
        if (b == null) {
            b = new q();
        }
        return b;
    }

    public void a(SharedPreferences sharedPreferences) {
        this.e = sharedPreferences;
    }

    public SharedPreferences b() {
        return this.e;
    }
}
