package ui.robot.rotate;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;

class ao implements OnClickListener {
    final /* synthetic */ SettingActivity a;

    ao(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void onClick(View view) {
        try {
            this.a.startActivity(new Intent(this.a, AppList.class));
        } catch (Exception e) {
        }
    }
}
