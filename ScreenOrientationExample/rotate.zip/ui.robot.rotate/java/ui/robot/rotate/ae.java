package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

class ae implements OnClickListener {
    final /* synthetic */ ServiceDialog a;

    ae(ServiceDialog serviceDialog) {
        this.a = serviceDialog;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.a.startActivity(new Intent(this.a.b, AboutActivity.class));
    }
}
