package ui.robot.rotate;

class v implements Runnable {
    final /* synthetic */ MyService a;

    v(MyService myService) {
        this.a = myService;
    }

    public void run() {
        this.a.z.a();
    }
}
