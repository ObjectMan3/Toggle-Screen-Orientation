package ui.robot.rotate;

import android.content.Context;
import android.content.pm.PackageManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

class k extends ArrayAdapter {
    final /* synthetic */ AppList a;

    k(AppList appList, Context context, int i) {
        this.a = appList;
        super(context, i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        PackageManager packageManager = this.a.getPackageManager();
        if (view == null) {
            view = this.a.getLayoutInflater().inflate(2130903040, viewGroup, false);
        }
        o oVar = (o) getItem(i);
        TextView textView = (TextView) view.findViewById(2131230721);
        if (oVar.a.loadLabel(packageManager) != null) {
            textView.setText(oVar.a.loadLabel(packageManager).toString());
        } else {
            textView.setText("");
        }
        textView = (TextView) view.findViewById(2131230722);
        if (oVar.a.applicationInfo.packageName != null) {
            textView.setText(oVar.a.applicationInfo.packageName);
        } else {
            textView.setText("");
        }
        textView = (TextView) view.findViewById(2131230723);
        if (oVar.e != null) {
            textView.setTextColor(-16711936);
            textView.setText(MyService.a(oVar.e, this.a.j));
        } else {
            textView.setText("");
        }
        ImageView imageView = (ImageView) view.findViewById(2131230720);
        imageView.setVisibility(0);
        if (oVar != null) {
            imageView.setImageDrawable(oVar.a.loadIcon(packageManager));
        }
        return view;
    }
}
