package ui.robot.rotate;

import android.content.Context;
import android.graphics.Canvas;
import android.media.AudioManager;
import android.view.LayoutInflater;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.SeekBar;

public class ab extends FrameLayout {
    boolean a = true;
    SeekBar b = null;
    SeekBar c = null;
    SeekBar d = null;
    SeekBar e = null;
    SeekBar f = null;
    AudioManager g = null;
    private Context h;
    private LayoutInflater i;
    private int j = 2;

    public ab(Context context) {
        super(context);
        try {
            this.a = false;
            this.h = context;
            this.i = LayoutInflater.from(context);
            this.i.inflate(2130903044, this);
            setVisibility(4);
        } catch (Exception e) {
        }
    }

    public void a() {
        setVisibility(4);
        this.a = false;
    }

    public void a(int i, int i2, int i3, int i4) {
        try {
            this.a = true;
            int orientation = ((WindowManager) this.h.getSystemService("window")).getDefaultDisplay().getOrientation();
            String str = "";
            str = "";
            if (orientation == 0) {
                str = "ROTATION_0";
            }
            if (orientation == 3) {
                str = "ROTATION_270";
            }
            if (orientation == 2) {
                str = "ROTATION_180";
            }
            if (orientation == 1) {
                str = "ROTATION_90";
            }
            if (i2 == 2) {
                str = "SCREEN_ORIENTATION_PORTRAIT";
            }
            if (i2 == 0) {
                str = "SCREEN_ORIENTATION_LANDSCAPE";
            }
            if (i2 == 8) {
                str = "SCREEN_ORIENTATION_REVERSE_LANDSCAPE";
            }
            if (i2 == 9) {
                str = "SCREEN_ORIENTATION_REVERSE_PORTRAIT";
            }
            if (orientation == 0) {
                if (i2 == 2) {
                    setBackgroundDrawable(getResources().getDrawable(2130837510));
                }
                if (i2 == 0) {
                    setBackgroundDrawable(getResources().getDrawable(2130837516));
                }
                if (i2 == 8) {
                    setBackgroundDrawable(getResources().getDrawable(2130837523));
                }
                if (i2 == 9) {
                    setBackgroundDrawable(getResources().getDrawable(2130837521));
                }
            }
            if (orientation == 3) {
                if (i2 == 2) {
                    setBackgroundDrawable(getResources().getDrawable(2130837517));
                }
                if (i2 == 0) {
                    setBackgroundDrawable(getResources().getDrawable(2130837520));
                }
                if (i2 == 9) {
                    setBackgroundDrawable(getResources().getDrawable(2130837524));
                }
            }
            if (orientation == 1) {
                if (i2 == 2) {
                    setBackgroundDrawable(getResources().getDrawable(2130837524));
                }
                if (i2 == 8) {
                    setBackgroundDrawable(getResources().getDrawable(2130837520));
                }
                if (i2 == 9) {
                    setBackgroundDrawable(getResources().getDrawable(2130837517));
                }
            }
            if (orientation == 2) {
                if (i2 == 2) {
                    setBackgroundDrawable(getResources().getDrawable(2130837521));
                }
                if (i2 == 0) {
                    setBackgroundDrawable(getResources().getDrawable(2130837523));
                }
                if (i2 == 8) {
                    setBackgroundDrawable(getResources().getDrawable(2130837516));
                }
            }
            getBackground().setAlpha(80);
            WindowManager windowManager = (WindowManager) this.h.getSystemService("window");
            LayoutParams layoutParams = new WindowManager.LayoutParams();
            layoutParams.height = i3;
            layoutParams.width = i3;
            this.j = i2;
            layoutParams.flags = i4;
            layoutParams.format = -3;
            layoutParams.type = 2003;
            layoutParams.gravity = i;
            setVisibility(4);
            windowManager.updateViewLayout(this, layoutParams);
            setVisibility(0);
        } catch (Exception e) {
        }
    }

    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
    }
}
