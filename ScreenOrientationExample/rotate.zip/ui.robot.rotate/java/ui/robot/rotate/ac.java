package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

class ac implements OnClickListener {
    final /* synthetic */ ServiceDialog a;

    ac(ServiceDialog serviceDialog) {
        this.a = serviceDialog;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        this.a.a.a = true;
        if (i == 0) {
            this.a.a.c = aa.ADAPTIVE;
        } else if (i == 1) {
            this.a.a.c = aa.FL;
        } else if (i == 2) {
            this.a.a.c = aa.FP;
        } else if (i == 3) {
            this.a.a.c = aa.FRP;
        } else if (i == 4) {
            this.a.a.c = aa.FRL;
        } else if (i == 5) {
            this.a.a.c = aa.AUTO;
        } else if (i == 6) {
            this.a.a.c = aa.STOCK_AUTO;
        } else if (i == 7) {
            this.a.a.c = aa.STOCK_MANUAL;
        } else {
            this.a.a.c = aa.DISABLE;
        }
        MyService.b(this.a.d, this.a.a, this.a.b);
        if (this.a.a.c == aa.DISABLE) {
            this.a.stopService(new Intent(this.a, MyService.class));
        } else {
            Intent intent = new Intent();
            intent.setAction(p.a);
            intent.putExtra("isVisible", "prefchanged");
            this.a.b.sendBroadcast(intent);
        }
        dialogInterface.dismiss();
        this.a.finish();
    }
}
