package ui.robot.rotate;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.View.OnClickListener;

class c implements OnClickListener {
    final /* synthetic */ AboutActivity a;

    c(AboutActivity aboutActivity) {
        this.a = aboutActivity;
    }

    public void onClick(View view) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("market://details?id=ui.robot.rotatedonate"));
        this.a.startActivity(intent);
        this.a.finish();
    }
}
