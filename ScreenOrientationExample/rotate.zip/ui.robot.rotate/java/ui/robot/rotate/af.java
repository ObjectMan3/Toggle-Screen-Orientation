package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

class af implements OnCancelListener {
    final /* synthetic */ ServiceDialog a;

    af(ServiceDialog serviceDialog) {
        this.a = serviceDialog;
    }

    public void onCancel(DialogInterface dialogInterface) {
        dialogInterface.dismiss();
        this.a.finish();
    }
}
