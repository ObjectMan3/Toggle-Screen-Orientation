package ui.robot.rotate;

import android.content.pm.ResolveInfo;
import java.util.Comparator;

class m implements Comparator {
    final /* synthetic */ l a;

    m(l lVar) {
        this.a = lVar;
    }

    public int a(ResolveInfo resolveInfo, ResolveInfo resolveInfo2) {
        return resolveInfo.loadLabel(this.a.a.a).toString().toLowerCase().compareTo(resolveInfo2.loadLabel(this.a.a.a).toString().toLowerCase());
    }

    public /* synthetic */ int compare(Object obj, Object obj2) {
        return a((ResolveInfo) obj, (ResolveInfo) obj2);
    }
}
