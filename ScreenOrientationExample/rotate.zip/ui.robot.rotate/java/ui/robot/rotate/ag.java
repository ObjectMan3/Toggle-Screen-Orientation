package ui.robot.rotate;

class ag implements Runnable {
    final /* synthetic */ SettingActivity a;

    ag(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void run() {
        this.a.p.a();
    }
}
