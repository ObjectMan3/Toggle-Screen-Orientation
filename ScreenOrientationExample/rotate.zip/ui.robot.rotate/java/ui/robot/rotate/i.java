package ui.robot.rotate;

import android.app.AlertDialog.Builder;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

class i implements OnItemClickListener {
    final /* synthetic */ AppList a;

    i(AppList appList) {
        this.a = appList;
    }

    public void onItemClick(AdapterView adapterView, View view, int i, long j) {
        CharSequence[] charSequenceArr = new CharSequence[]{this.a.getString(2131034115), this.a.getString(2131034116), this.a.getString(2131034117), this.a.getString(2131034118), this.a.getString(2131034119), this.a.getString(2131034120), this.a.getString(2131034121), this.a.getString(2131034122), this.a.getString(2131034123)};
        new Builder(this.a).setTitle("Rotation mode").setItems(charSequenceArr, new j(this, ((TextView) view.findViewById(2131230722)).getText().toString(), charSequenceArr)).create().show();
    }
}
