package ui.robot.rotate;

import a.a.a.a;
import a.a.a.c;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.Settings.System;
import android.util.Log;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MyService extends Service {
    public static Context a;
    public static List c = new ArrayList();
    static int r = 2;
    private int A = 0;
    private int B = 2;
    private int C = 2;
    private int D = 2;
    private int E = 2;
    private boolean F = false;
    private OrientationEventListener G;
    private WindowManager H;
    private View I;
    private LayoutParams J;
    private CharSequence K;
    private ActivityManager L;
    private List M;
    private SharedPreferences N;
    private BroadcastReceiver O = new u(this);
    Map b;
    protected Vibrator d;
    int e = 3000;
    z f = new z();
    protected aa g;
    public String h = "";
    aa i = aa.INIT;
    String j = "Mode: ";
    protected Runnable k = new r(this);
    BroadcastReceiver l = new s(this);
    OnClickListener m = new t(this);
    int n = 776;
    int o = 2005;
    int p = 0;
    boolean q;
    Handler s = new Handler();
    Handler t = new Handler();
    protected int u = 0;
    protected boolean v = true;
    String w = "";
    Handler x = new Handler();
    Runnable y = new v(this);
    private ab z;

    public static CharSequence a(aa aaVar, Context context) {
        CharSequence charSequence = null;
        if (aa.ADAPTIVE == aaVar) {
            charSequence = context.getString(2131034116);
        }
        if (aa.FL == aaVar) {
            charSequence = context.getString(2131034117);
        }
        if (aa.FP == aaVar) {
            charSequence = context.getString(2131034118);
        }
        if (aa.FRP == aaVar) {
            charSequence = context.getString(2131034119);
        }
        if (aa.FRL == aaVar) {
            charSequence = context.getString(2131034120);
        }
        if (aa.AUTO == aaVar) {
            charSequence = context.getString(2131034121);
        }
        if (aa.STOCK_AUTO == aaVar) {
            charSequence = context.getString(2131034122);
        }
        if (aa.STOCK_MANUAL == aaVar) {
            charSequence = context.getString(2131034123);
        }
        return aa.DISABLE == aaVar ? context.getString(2131034124) : charSequence;
    }

    public static aa a(CharSequence charSequence, Context context) {
        aa aaVar = aa.ADAPTIVE;
        if (context.getString(2131034116).equals(charSequence)) {
            aaVar = aa.ADAPTIVE;
        }
        if (context.getString(2131034117).equals(charSequence)) {
            aaVar = aa.FL;
        }
        if (context.getString(2131034118).equals(charSequence)) {
            aaVar = aa.FP;
        }
        if (context.getString(2131034119).equals(charSequence)) {
            aaVar = aa.FRP;
        }
        if (context.getString(2131034120).equals(charSequence)) {
            aaVar = aa.FRL;
        }
        if (context.getString(2131034121).equals(charSequence)) {
            aaVar = aa.AUTO;
        }
        if (context.getString(2131034122).equals(charSequence)) {
            aaVar = aa.STOCK_AUTO;
        }
        if (context.getString(2131034123).equals(charSequence)) {
            aaVar = aa.STOCK_MANUAL;
        }
        return context.getString(2131034124).equals(charSequence) ? aa.DISABLE : aaVar;
    }

    public static void a(SharedPreferences sharedPreferences, z zVar, Context context) {
        zVar.c = a(sharedPreferences.getString("mode", context.getString(2131034116)), context);
        zVar.b = sharedPreferences.getInt("size", 130);
        zVar.a = sharedPreferences.getBoolean("enable", false);
        zVar.e = sharedPreferences.getBoolean("Cmode", false);
        zVar.d = sharedPreferences.getBoolean("Bmode", false);
        zVar.f = sharedPreferences.getBoolean("Vmode", true);
        zVar.g = sharedPreferences.getBoolean("Nmode", true);
        zVar.i = sharedPreferences.getBoolean("lockmode", true);
        zVar.h = sharedPreferences.getBoolean("perapp", false);
    }

    static String b(int i) {
        return i == 2 ? "portrait" : i == 0 ? "LANDSCAPE" : i == 8 ? "REVERSE_LANDSCAPE" : i == 9 ? "REVERSE_PORTRAIT" : "unknown";
    }

    public static void b(SharedPreferences sharedPreferences, z zVar, Context context) {
        Editor edit = sharedPreferences.edit();
        edit.putString("mode", a(zVar.c, context).toString());
        edit.putInt("size", zVar.b);
        edit.putBoolean("enable", zVar.a);
        edit.putBoolean("Cmode", zVar.e);
        edit.putBoolean("Bmode", zVar.d);
        edit.putBoolean("Vmode", zVar.f);
        edit.putBoolean("Nmode", zVar.g);
        edit.putBoolean("lockmode", zVar.i);
        edit.putBoolean("perapp", zVar.h);
        edit.commit();
    }

    int a(Intent intent) {
        try {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                String valueOf = String.valueOf(extras.getString("id"));
                if (valueOf.equalsIgnoreCase("update")) {
                    this.f.c = a(q.c().b().getString("mode", a.getString(2131034116)), a);
                    a(this.f.c, this.K);
                    a(this.f.c);
                }
                valueOf.equalsIgnoreCase("present");
            }
            this.b = q.a();
            a.a();
        } catch (Exception e) {
        }
        return 1;
    }

    public String a(ActivityManager activityManager) {
        return ((RunningTaskInfo) activityManager.getRunningTasks(1).get(0)).topActivity.getPackageName();
    }

    public aa a(Map map, String str, Context context, String str2) {
        try {
            for (String equalsIgnoreCase : this.M) {
                if (str.equalsIgnoreCase(equalsIgnoreCase)) {
                    return aa.STOCK_AUTO;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public void a() {
        b(this.D);
        if (r == 2) {
            if (this.D == 2) {
                a(0);
            } else if (this.D == 0) {
                a(0);
            } else if (this.D == 8) {
                a(0);
            } else {
                a(2);
            }
            this.J.screenOrientation = this.D;
            this.f.j = this.J;
            if (this.F) {
                this.H.updateViewLayout(this.I, this.J);
            } else {
                this.F = true;
                this.H.addView(this.I, this.J);
            }
        }
        this.E = this.D;
    }

    public void a(int i) {
        System.putInt(getContentResolver(), "user_rotation", i);
    }

    void a(aa aaVar) {
        a(aaVar, false);
    }

    void a(aa aaVar, CharSequence charSequence) {
        CharSequence charSequence2 = "";
        if (aaVar != null) {
            this.j = a.getString(2131034129);
            charSequence2 = this.j + " " + a(aaVar, a);
        }
        Notification notification = new Notification(2130837527, charSequence2, System.currentTimeMillis());
        notification.setLatestEventInfo(this, charSequence, charSequence2, PendingIntent.getActivity(this, 0, new Intent(this, ServiceDialog.class), 2097152));
        startForeground(1, notification);
    }

    void a(aa aaVar, boolean z) {
        if (this.q != this.f.i) {
            c();
        }
        this.g = aaVar;
        if (aaVar == aa.ADAPTIVE) {
            a(false);
            this.D = this.f.j.screenOrientation;
            if (z) {
                this.D = 2;
                a();
                return;
            }
            a();
        } else if (aaVar == aa.FL) {
            e();
        } else if (aaVar == aa.FP) {
            d();
        } else if (aaVar == aa.FRP) {
            f();
        } else if (aaVar == aa.FRL) {
            g();
        } else if (aaVar == aa.AUTO) {
            a(true);
        } else if (aaVar == aa.STOCK_AUTO) {
            h();
        } else {
            i();
        }
    }

    public void a(boolean z) {
        System.putInt(getContentResolver(), "accelerometer_rotation", z ? 1 : 0);
    }

    void b() {
        try {
            Map all = getApplicationContext().getSharedPreferences("perapp", 1).getAll();
            q.a().clear();
            for (Entry entry : all.entrySet()) {
                q.a().put((String) entry.getKey(), aa.valueOf((String) entry.getValue()));
            }
        } catch (Exception e) {
        }
    }

    void c() {
        if (this.f.i) {
            this.o = 2005;
            this.n = 8;
            this.n = 776;
        } else {
            this.o = 2006;
            this.n = 525064;
        }
        if (this.F) {
            this.H.removeView(this.I);
            this.F = true;
            this.J = new LayoutParams();
            this.J.width = 0;
            this.J.height = 0;
            this.J.flags = this.n;
            this.J.type = this.o;
            this.J.format = -1;
            this.J.gravity = 51;
            this.J.x = -5;
            this.J.y = -5;
            this.J.screenOrientation = 0;
            this.H.addView(this.I, this.J);
            this.q = this.f.i;
        }
    }

    void d() {
        this.D = 2;
        if (r == 2) {
            a(false);
            a();
        }
    }

    void e() {
        this.D = 0;
        if (r == 2) {
            a(false);
            a();
        }
    }

    void f() {
        this.D = 9;
        if (r == 2) {
            a(false);
            a();
        }
    }

    void g() {
        this.D = 8;
        if (r == 2) {
            a(false);
            a();
        }
    }

    void h() {
        a(true);
        if (this.F) {
            this.H.removeView(this.I);
            this.F = false;
        }
    }

    void i() {
        if (this.F) {
            this.H.removeView(this.I);
            this.F = false;
        }
        a(false);
        a(0);
    }

    boolean j() {
        try {
            z zVar = this.f;
            a(this.N, this.f, a);
            aa aaVar = zVar.c;
            aaVar = this.f.c;
            a(this.f.c, this.K);
            a(this.f.c);
        } catch (Exception e) {
        }
        return false;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (configuration.orientation != 2) {
            int i = configuration.orientation;
        }
    }

    public void onCreate() {
        try {
            if (VERSION.SDK_INT <= 10) {
                r = 2;
            } else {
                r = 3;
            }
            r = 2;
            a = getApplicationContext();
            this.L = (ActivityManager) a.getSystemService("activity");
            this.M = c.a(a);
            this.d = (Vibrator) a.getSystemService("vibrator");
            Thread.setDefaultUncaughtExceptionHandler(new w(this));
            this.j = a.getString(2131034129);
            this.K = getString(2131034113);
            q.c().a(PreferenceManager.getDefaultSharedPreferences(a));
            b();
            this.N = PreferenceManager.getDefaultSharedPreferences(a);
            a(this.N, this.f, a);
            if (this.f.i) {
                this.o = 2005;
                this.n = 8;
                this.n = 776;
            } else {
                this.o = 2006;
                this.n = 525064;
            }
            this.I = new View(getApplicationContext());
            this.H = (WindowManager) getSystemService("window");
            this.J = new LayoutParams(0, 0, this.o, this.n, -1);
            this.J.gravity = 51;
            this.J.x = -5;
            this.J.y = -5;
            this.J.screenOrientation = 0;
            registerReceiver(this.O, new IntentFilter(p.a));
            IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_ON");
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            registerReceiver(this.l, intentFilter);
            this.z = new ab(a);
            this.z.setOnClickListener(this.m);
            this.H.addView(this.z, new LayoutParams(2003, 8));
            this.f.c = a(q.c().b().getString("mode", a.getString(2131034116)), a);
            a(this.f.c, this.K);
            a(this.f.c);
            this.t.post(this.k);
        } catch (Exception e) {
        }
        this.G = new y(this, a);
        this.G.enable();
    }

    public void onDestroy() {
        Log.d("rotate", "onDestroy");
        this.G.disable();
        if (this.O != null) {
            unregisterReceiver(this.O);
        }
        if (this.l != null) {
            unregisterReceiver(this.l);
        }
        a(aa.STOCK_MANUAL);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            new Thread(new x(this, intent)).start();
        } catch (Exception e) {
        }
        return 1;
    }
}
