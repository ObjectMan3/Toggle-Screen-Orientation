package ui.robot.rotate;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

class ak implements OnCheckedChangeListener {
    final /* synthetic */ SettingActivity a;

    ak(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        this.a.a.g = z;
    }
}
