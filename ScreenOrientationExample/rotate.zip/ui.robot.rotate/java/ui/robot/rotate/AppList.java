package ui.robot.rotate;

import a.a.a.c;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class AppList extends Activity {
    PackageManager a;
    List b = new ArrayList();
    List c = new ArrayList();
    ArrayAdapter d;
    List e;
    Handler f = new h(this);
    ProgressDialog g;
    private ListView h;
    private boolean i = true;
    private Context j;

    void a() {
        Map all = getApplicationContext().getSharedPreferences("perapp", 1).getAll();
        q.a().clear();
        for (Entry entry : all.entrySet()) {
            q.a().put((String) entry.getKey(), aa.valueOf((String) entry.getValue()));
        }
    }

    boolean a(String str) {
        for (String equals : this.e) {
            if (equals.equals(str)) {
                return true;
            }
        }
        return false;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            this.j = getApplicationContext();
            this.e = c.a(this.j);
            this.a = getPackageManager();
            setContentView(2130903041);
            this.h = (ListView) findViewById(2131230724);
            this.h.setFastScrollEnabled(true);
            registerForContextMenu(this.h);
            this.h.setOnItemClickListener(new i(this));
            this.d = new k(this, this, 2130903040);
        } catch (Exception e) {
        }
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();
        try {
            Editor edit = getApplicationContext().getSharedPreferences("perapp", 1).edit();
            edit.clear();
            q.c();
            for (String str : q.a().keySet()) {
                q.c();
                edit.putString(str, ((aa) q.a().get(str)).toString());
            }
            edit.commit();
        } catch (Exception e) {
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            a();
            new Thread(new l(this)).start();
        } catch (Exception e) {
        }
    }
}
