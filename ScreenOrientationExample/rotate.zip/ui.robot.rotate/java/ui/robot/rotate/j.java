package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class j implements OnClickListener {
    final /* synthetic */ i a;
    private final /* synthetic */ String b;
    private final /* synthetic */ CharSequence[] c;

    j(i iVar, String str, CharSequence[] charSequenceArr) {
        this.a = iVar;
        this.b = str;
        this.c = charSequenceArr;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        if (i == 0) {
            q.a().remove(this.b);
        } else if (i >= 1 && i <= 8) {
            q.a().put(this.b, MyService.a(this.c[i], this.a.a.j));
        }
        this.a.a.f.sendEmptyMessage(1);
        dialogInterface.dismiss();
    }
}
