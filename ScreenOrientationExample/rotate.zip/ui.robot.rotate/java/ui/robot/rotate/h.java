package ui.robot.rotate;

import android.app.ProgressDialog;
import android.os.Handler;
import android.os.Message;
import android.widget.ArrayAdapter;

class h extends Handler {
    final /* synthetic */ AppList a;

    h(AppList appList) {
        this.a = appList;
    }

    public void handleMessage(Message message) {
        switch (message.what) {
            case 1:
                try {
                    ArrayAdapter arrayAdapter = (ArrayAdapter) this.a.h.getAdapter();
                    arrayAdapter.setNotifyOnChange(false);
                    arrayAdapter.clear();
                    for (o oVar : this.a.c) {
                        oVar.e = (aa) q.a().get(oVar.a.packageName);
                        arrayAdapter.add(oVar);
                    }
                    arrayAdapter.notifyDataSetChanged();
                    return;
                } catch (Exception e) {
                    return;
                }
            case 2:
                this.a.d.clear();
                for (o add : this.a.c) {
                    this.a.d.add(add);
                }
                this.a.h.setAdapter(this.a.d);
                return;
            case 3:
                if (this.a.g == null) {
                    this.a.g = new ProgressDialog(this.a);
                }
                this.a.g.setMessage("Loading");
                this.a.g.setIndeterminate(true);
                this.a.g.setProgressStyle(0);
                this.a.g.show();
                return;
            case 5:
                if (this.a.g != null) {
                    this.a.g.setProgress(this.a.g.getProgress() + 1);
                    return;
                }
                return;
            case 6:
                if (this.a.g != null) {
                    this.a.g.dismiss();
                    this.a.g = null;
                    return;
                }
                return;
            default:
                return;
        }
    }
}
