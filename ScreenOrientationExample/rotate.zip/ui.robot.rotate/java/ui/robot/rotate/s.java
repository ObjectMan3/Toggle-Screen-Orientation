package ui.robot.rotate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class s extends BroadcastReceiver {
    final /* synthetic */ MyService a;

    s(MyService myService) {
        this.a = myService;
    }

    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
            boolean z = this.a.f.i;
            this.a.t.removeCallbacks(this.a.k);
            this.a.G.disable();
        } else if (intent.getAction().equals("android.intent.action.SCREEN_ON")) {
            this.a.t.post(this.a.k);
            this.a.G.enable();
        }
    }
}
