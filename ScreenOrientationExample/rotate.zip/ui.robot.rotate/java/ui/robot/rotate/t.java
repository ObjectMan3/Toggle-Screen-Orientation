package ui.robot.rotate;

import android.view.View;
import android.view.View.OnClickListener;

class t implements OnClickListener {
    final /* synthetic */ MyService a;

    t(MyService myService) {
        this.a = myService;
    }

    public void onClick(View view) {
        this.a.z.a();
        this.a.d.vibrate(30);
        this.a.a(false);
        this.a.a();
    }
}
