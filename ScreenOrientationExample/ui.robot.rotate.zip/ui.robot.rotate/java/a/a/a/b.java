/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package a.a.a;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class b {
    /*
     * Enabled aggressive block sorting
     */
    public static int a() {
        StackTraceElement[] arrstackTraceElement = new Throwable().getStackTrace();
        if (arrstackTraceElement.length <= 0 || arrstackTraceElement.length < 2) {
            return -1;
        }
        return arrstackTraceElement[1].getLineNumber();
    }

    public static String a(Object object) {
        String string = object.getClass().toString().substring(6);
        return String.valueOf((Object)Pattern.compile((String)"\\$.*").matcher((CharSequence)string).replaceAll("")) + ".java:";
    }
}

