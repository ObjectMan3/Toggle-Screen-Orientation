/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package a.a.a;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class c {
    public static String[] a = new String[]{"sun_", "mon_", "tue_", "wed_", "thu_", "fri_", "sat_"};

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static List a(Context context) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        ArrayList arrayList = new ArrayList();
        try {
            Iterator iterator = packageManager.queryIntentActivities(intent, 0).iterator();
            do {
                if (!iterator.hasNext()) {
                    return arrayList;
                }
                arrayList.add((Object)((ResolveInfo)iterator.next()).activityInfo.packageName);
            } while (true);
        }
        catch (Exception var4_5) {
            var4_5.printStackTrace();
            return null;
        }
    }
}

