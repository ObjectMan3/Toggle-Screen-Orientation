/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  java.lang.Object
 *  java.lang.String
 */
package a.a.a;

import android.content.Context;
import android.os.PowerManager;

public class a {
    private static PowerManager.WakeLock a;

    public static void a() {
        if (a != null) {
            a.release();
            a = null;
        }
    }

    public static void a(Context context, String string) {
        if (a != null) {
            return;
        }
        a = ((PowerManager)context.getSystemService("power")).newWakeLock(1, string);
        a.acquire();
    }
}

