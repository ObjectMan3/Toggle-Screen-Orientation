/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import ui.robot.rotate.AppList;
import ui.robot.rotate.j;

class i
implements AdapterView.OnItemClickListener {
    final /* synthetic */ AppList a;

    i(AppList appList) {
        this.a = appList;
    }

    static /* synthetic */ AppList a(i i2) {
        return i2.a;
    }

    public void onItemClick(AdapterView adapterView, View view, int n2, long l2) {
        String string = ((TextView)view.findViewById(2131230722)).getText().toString();
        CharSequence[] arrcharSequence = new CharSequence[]{this.a.getString(2131034115), this.a.getString(2131034116), this.a.getString(2131034117), this.a.getString(2131034118), this.a.getString(2131034119), this.a.getString(2131034120), this.a.getString(2131034121), this.a.getString(2131034122), this.a.getString(2131034123)};
        j j2 = new j((i)this, string, arrcharSequence);
        new AlertDialog.Builder((Context)this.a).setTitle((CharSequence)"Rotation mode").setItems(arrcharSequence, (DialogInterface.OnClickListener)j2).create().show();
    }
}

