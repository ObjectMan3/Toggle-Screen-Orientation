/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.widget.CompoundButton;
import ui.robot.rotate.SettingActivity;
import ui.robot.rotate.z;

class aj
implements CompoundButton.OnCheckedChangeListener {
    final /* synthetic */ SettingActivity a;

    aj(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
        z z2 = this.a.a;
        boolean bl2 = bl;
        z2.a = bl2;
    }
}

