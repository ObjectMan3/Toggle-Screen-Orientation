/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.view.OrientationEventListener
 *  java.lang.Runnable
 */
package ui.robot.rotate;

import android.content.Context;
import android.os.Handler;
import android.view.OrientationEventListener;
import ui.robot.rotate.MyService;
import ui.robot.rotate.aa;
import ui.robot.rotate.ab;
import ui.robot.rotate.z;

class y
extends OrientationEventListener {
    final /* synthetic */ MyService a;

    public y(MyService myService, Context context) {
        this.a = myService;
        super(context);
    }

    /*
     * Enabled aggressive block sorting
     */
    void a() {
        if (MyService.e(this.a) != MyService.f(this.a) && MyService.g(this.a) != MyService.f(this.a)) {
            MyService.c(this.a, MyService.f(this.a));
            this.a.s.removeCallbacks(this.a.y);
            if (MyService.c((MyService)this.a).a) {
                MyService.c(this.a).a();
            }
            if (this.a.g == aa.f) {
                this.a.a();
            } else {
                MyService.c(this.a).a(17, MyService.f(this.a), this.a.f.b, 8);
                this.a.s.postDelayed(this.a.y, (long)this.a.e);
            }
        }
        MyService.d(this.a, MyService.f(this.a));
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void onOrientationChanged(int n2) {
        if (n2 == -1) {
            return;
        }
        if (this.a.g == aa.h) return;
        if (this.a.g == aa.g) return;
        if (this.a.g == aa.b) return;
        if (this.a.g == aa.c) return;
        if (this.a.g == aa.e) return;
        if (this.a.g == aa.d) return;
        if (this.a.g == aa.g) return;
        if (this.a.g == aa.g) return;
        MyService myService = this.a;
        MyService.a(myService, 1 + MyService.d(myService));
        if (MyService.d(this.a) != 1) return;
        if (n2 < 25 || n2 > 335) {
            MyService.b(this.a, 2);
            this.a();
        }
        if (n2 < 295 && n2 > 245) {
            MyService.b(this.a, 0);
            this.a();
        }
        if (n2 < 115 && n2 > 65) {
            MyService.b(this.a, 8);
            this.a();
        }
        if (n2 < 205 && n2 > 155) {
            MyService.b(this.a, 9);
            this.a();
        }
        MyService.a(this.a, 0);
    }
}

