/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package ui.robot.rotate;

import ui.robot.rotate.SettingActivity;

class ag
implements Runnable {
    final /* synthetic */ SettingActivity a;

    ag(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void run() {
        SettingActivity.a(this.a).a();
    }
}

