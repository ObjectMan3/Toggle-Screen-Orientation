/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Comparator
 */
package ui.robot.rotate;

import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.Comparator;
import ui.robot.rotate.AppList;
import ui.robot.rotate.l;

class m
implements Comparator {
    final /* synthetic */ l a;

    m(l l2) {
        this.a = l2;
    }

    public int a(ResolveInfo resolveInfo, ResolveInfo resolveInfo2) {
        return resolveInfo.loadLabel(l.a((l)this.a).a).toString().toLowerCase().compareTo(resolveInfo2.loadLabel(l.a((l)this.a).a).toString().toLowerCase());
    }

    public /* synthetic */ int compare(Object object, Object object2) {
        return this.a((ResolveInfo)object, (ResolveInfo)object2);
    }
}

