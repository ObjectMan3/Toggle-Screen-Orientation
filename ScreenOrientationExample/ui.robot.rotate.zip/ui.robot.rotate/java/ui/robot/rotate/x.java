/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 *  java.lang.Runnable
 */
package ui.robot.rotate;

import android.content.Intent;
import ui.robot.rotate.MyService;

class x
implements Runnable {
    final /* synthetic */ MyService a;
    private final /* synthetic */ Intent b;

    x(MyService myService, Intent intent) {
        this.a = myService;
        this.b = intent;
    }

    public void run() {
        this.a.a(this.b);
    }
}

