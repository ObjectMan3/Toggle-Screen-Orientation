/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  java.lang.Object
 *  java.lang.Runnable
 */
package ui.robot.rotate;

import android.os.Handler;
import ui.robot.rotate.SettingActivity;

class ah
implements Runnable {
    final /* synthetic */ SettingActivity a;

    ah(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void run() {
        this.a.b.removeCallbacks(this.a.d);
        this.a.b.postDelayed(this.a.d, 1000);
        SettingActivity.a(this.a).a(17, 2, this.a.f, 24);
    }
}

