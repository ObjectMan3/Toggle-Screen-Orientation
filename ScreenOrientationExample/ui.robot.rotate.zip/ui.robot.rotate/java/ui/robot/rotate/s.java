/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Handler
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import ui.robot.rotate.MyService;

class s
extends BroadcastReceiver {
    final /* synthetic */ MyService a;

    s(MyService myService) {
        this.a = myService;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals((Object)"android.intent.action.SCREEN_OFF")) {
            this.a.t.removeCallbacks(this.a.k);
            MyService.b(this.a).disable();
            return;
        } else {
            if (!intent.getAction().equals((Object)"android.intent.action.SCREEN_ON")) return;
            {
                this.a.t.post(this.a.k);
                MyService.b(this.a).enable();
                return;
            }
        }
    }
}

