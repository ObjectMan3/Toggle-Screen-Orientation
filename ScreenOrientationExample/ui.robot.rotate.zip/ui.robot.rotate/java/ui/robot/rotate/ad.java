/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  java.lang.Class
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import ui.robot.rotate.ServiceDialog;
import ui.robot.rotate.SettingActivity;

class ad
implements DialogInterface.OnClickListener {
    final /* synthetic */ ServiceDialog a;

    ad(ServiceDialog serviceDialog) {
        this.a = serviceDialog;
    }

    public void onClick(DialogInterface dialogInterface, int n2) {
        Intent intent = new Intent(ServiceDialog.b(this.a), (Class)SettingActivity.class);
        this.a.startActivityForResult(intent, 2);
    }
}

