/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.view.WindowManager;
import ui.robot.rotate.aa;

public class z {
    boolean a = false;
    int b = 130;
    aa c;
    boolean d = false;
    boolean e = true;
    boolean f = true;
    boolean g = true;
    boolean h = false;
    boolean i = true;
    WindowManager.LayoutParams j = new WindowManager.LayoutParams();

    public z() {
        this.j.screenOrientation = 2;
    }
}

