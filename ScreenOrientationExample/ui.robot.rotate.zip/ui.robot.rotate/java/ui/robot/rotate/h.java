/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.pm.ActivityInfo
 *  android.os.Handler
 *  android.os.Message
 *  android.widget.ArrayAdapter
 *  android.widget.ListAdapter
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 */
package ui.robot.rotate;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Handler;
import android.os.Message;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import java.util.Iterator;
import java.util.List;
import ui.robot.rotate.AppList;
import ui.robot.rotate.aa;
import ui.robot.rotate.o;
import ui.robot.rotate.q;

class h
extends Handler {
    final /* synthetic */ AppList a;

    h(AppList appList) {
        this.a = appList;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void handleMessage(Message message) {
        switch (message.what) {
            default: {
                return;
            }
            case 1: {
                ArrayAdapter arrayAdapter = (ArrayAdapter)AppList.a(this.a).getAdapter();
                arrayAdapter.setNotifyOnChange(false);
                arrayAdapter.clear();
                Iterator iterator = this.a.c.iterator();
                do {
                    if (!iterator.hasNext()) {
                        arrayAdapter.notifyDataSetChanged();
                        return;
                    }
                    o o2 = (o)iterator.next();
                    o2.e = (aa)((Object)q.a().get((Object)o2.a.packageName));
                    arrayAdapter.add((Object)o2);
                } while (true);
            }
            case 2: {
                this.a.d.clear();
                Iterator iterator = this.a.c.iterator();
                do {
                    if (!iterator.hasNext()) {
                        AppList.a(this.a).setAdapter((ListAdapter)this.a.d);
                        return;
                    }
                    o o3 = (o)iterator.next();
                    this.a.d.add((Object)o3);
                } while (true);
            }
            case 3: {
                if (this.a.g == null) {
                    this.a.g = new ProgressDialog((Context)this.a);
                }
                this.a.g.setMessage((CharSequence)"Loading");
                this.a.g.setIndeterminate(true);
                this.a.g.setProgressStyle(0);
                this.a.g.show();
                return;
            }
            case 5: {
                if (this.a.g == null) return;
                this.a.g.setProgress(1 + this.a.g.getProgress());
                return;
            }
            case 6: 
        }
        if (this.a.g == null) return;
        this.a.g.dismiss();
        this.a.g = null;
        return;
        catch (Exception exception) {
            return;
        }
    }
}

