/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import ui.robot.rotate.AboutActivity;

class b
implements View.OnClickListener {
    final /* synthetic */ AboutActivity a;

    b(AboutActivity aboutActivity) {
        this.a = aboutActivity;
    }

    public void onClick(View view) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse((String)("market://details?id=" + this.a.getPackageName())));
        this.a.startActivity(intent);
        this.a.finish();
    }
}

