/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.os.Handler
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.Iterator
 *  java.util.List
 */
package ui.robot.rotate;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import ui.robot.rotate.AppList;
import ui.robot.rotate.aa;
import ui.robot.rotate.m;
import ui.robot.rotate.n;
import ui.robot.rotate.o;
import ui.robot.rotate.q;

class l
implements Runnable {
    final /* synthetic */ AppList a;

    l(AppList appList) {
        this.a = appList;
    }

    static /* synthetic */ AppList a(l l2) {
        return l2.a;
    }

    public void run() {
        try {
            this.a.f.sendEmptyMessage(3);
            Intent intent = new Intent("android.intent.action.MAIN", null);
            intent.addCategory("android.intent.category.LAUNCHER");
            List list = this.a.getPackageManager().queryIntentActivities(intent, 0);
            this.a.c.clear();
            Collections.sort((List)list, (Comparator)new m(this));
            Iterator iterator = list.iterator();
            do {
                if (!iterator.hasNext()) {
                    Collections.sort((List)this.a.c, (Comparator)new n(this));
                    this.a.f.sendEmptyMessage(6);
                    this.a.f.sendEmptyMessage(2);
                    return;
                }
                ResolveInfo resolveInfo = (ResolveInfo)iterator.next();
                if (this.a.a(resolveInfo.activityInfo.packageName)) continue;
                aa aa2 = (aa)((Object)q.a().get((Object)resolveInfo.activityInfo.packageName));
                o o2 = new o(resolveInfo.activityInfo, null, null, "", aa2);
                this.a.c.add((Object)o2);
            } while (true);
        }
        catch (Exception var1_7) {
            return;
        }
    }
}

