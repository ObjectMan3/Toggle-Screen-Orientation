/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.content.DialogInterface;
import ui.robot.rotate.ServiceDialog;

class af
implements DialogInterface.OnCancelListener {
    final /* synthetic */ ServiceDialog a;

    af(ServiceDialog serviceDialog) {
        this.a = serviceDialog;
    }

    public void onCancel(DialogInterface dialogInterface) {
        dialogInterface.dismiss();
        this.a.finish();
    }
}

