/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.graphics.drawable.Drawable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ArrayAdapter
 *  android.widget.ImageView
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import ui.robot.rotate.AppList;
import ui.robot.rotate.MyService;
import ui.robot.rotate.aa;
import ui.robot.rotate.o;

class k
extends ArrayAdapter {
    final /* synthetic */ AppList a;

    k(AppList appList, Context context, int n2) {
        this.a = appList;
        super(context, n2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public View getView(int n2, View view, ViewGroup viewGroup) {
        PackageManager packageManager = this.a.getPackageManager();
        if (view == null) {
            view = this.a.getLayoutInflater().inflate(2130903040, viewGroup, false);
        }
        o o2 = (o)this.getItem(n2);
        TextView textView = (TextView)view.findViewById(2131230721);
        if (o2.a.loadLabel(packageManager) != null) {
            textView.setText((CharSequence)o2.a.loadLabel(packageManager).toString());
        } else {
            textView.setText((CharSequence)"");
        }
        TextView textView2 = (TextView)view.findViewById(2131230722);
        if (o2.a.applicationInfo.packageName != null) {
            textView2.setText((CharSequence)o2.a.applicationInfo.packageName);
        } else {
            textView2.setText((CharSequence)"");
        }
        TextView textView3 = (TextView)view.findViewById(2131230723);
        if (o2.e != null) {
            textView3.setTextColor(-16711936);
            textView3.setText(MyService.a(o2.e, AppList.b(this.a)));
        } else {
            textView3.setText((CharSequence)"");
        }
        ImageView imageView = (ImageView)view.findViewById(2131230720);
        imageView.setVisibility(0);
        if (o2 != null) {
            imageView.setImageDrawable(o2.a.loadIcon(packageManager));
        }
        return view;
    }
}

