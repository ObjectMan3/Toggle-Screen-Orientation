/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.text.Html
 *  android.text.method.LinkMovementMethod
 *  android.text.method.MovementMethod
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import ui.robot.rotate.a;
import ui.robot.rotate.b;
import ui.robot.rotate.c;

public class AboutActivity
extends Activity {
    private Context a;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    static String a(PackageManager packageManager, String string) {
        try {
            String string2 = packageManager.getPackageInfo((String)string, (int)0).versionName;
            if (string2 != null) return string2;
            return "";
        }
        catch (PackageManager.NameNotFoundException var2_3) {
            return "";
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.a = this.getApplicationContext();
        this.setContentView(2130903046);
        (ScrollView)this.findViewById(2131230746);
        TextView textView = (TextView)this.findViewById(2131230747);
        Object[] arrobject = new Object[]{AboutActivity.a(this.getPackageManager(), this.getPackageName()), AboutActivity.a(this.getPackageManager(), this.getPackageName())};
        textView.setText((CharSequence)Html.fromHtml((String)this.getString(2131034132, arrobject)));
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        ((Button)this.findViewById(2131230750)).setOnClickListener((View.OnClickListener)new a((AboutActivity)this));
        ((Button)this.findViewById(2131230748)).setOnClickListener((View.OnClickListener)new b((AboutActivity)this));
        ((Button)this.findViewById(2131230749)).setOnClickListener((View.OnClickListener)new c((AboutActivity)this));
    }
}

