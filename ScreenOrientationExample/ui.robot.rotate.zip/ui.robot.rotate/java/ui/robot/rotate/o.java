/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.pm.ActivityInfo
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.pm.ActivityInfo;
import android.graphics.drawable.Drawable;
import ui.robot.rotate.aa;

final class o {
    ActivityInfo a;
    String b;
    Drawable c;
    String d;
    aa e;

    public o(ActivityInfo activityInfo, String string, Drawable drawable, String string2, aa aa2) {
        this.a = activityInfo;
        this.b = string;
        this.c = drawable;
        this.d = string2;
        this.e = aa2;
    }
}

