/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package ui.robot.rotate;

final class aa
extends Enum {
    public static final /* enum */ aa a = new aa();
    public static final /* enum */ aa b = new aa();
    public static final /* enum */ aa c = new aa();
    public static final /* enum */ aa d = new aa();
    public static final /* enum */ aa e = new aa();
    public static final /* enum */ aa f = new aa();
    public static final /* enum */ aa g = new aa();
    public static final /* enum */ aa h = new aa();
    public static final /* enum */ aa i = new aa();
    public static final /* enum */ aa j = new aa();
    private static final /* synthetic */ aa[] k;

    static {
        aa[] arraa = new aa[]{a, b, c, d, e, f, g, h, i, j};
        k = arraa;
    }

    private aa() {
        super(string, n2);
    }

    public static aa valueOf(String string) {
        return (aa)Enum.valueOf((Class)aa.class, (String)string);
    }

    public static aa[] values() {
        aa[] arraa = k;
        int n2 = arraa.length;
        aa[] arraa2 = new aa[n2];
        System.arraycopy((Object)arraa, (int)0, (Object)arraa2, (int)0, (int)n2);
        return arraa2;
    }
}

