/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package ui.robot.rotate;

import ui.robot.rotate.MyService;

class v
implements Runnable {
    final /* synthetic */ MyService a;

    v(MyService myService) {
        this.a = myService;
    }

    public void run() {
        MyService.c(this.a).a();
    }
}

