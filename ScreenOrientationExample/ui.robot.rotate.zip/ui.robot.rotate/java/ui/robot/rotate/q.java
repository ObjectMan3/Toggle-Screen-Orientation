/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  java.util.Map
 */
package ui.robot.rotate;

import android.content.SharedPreferences;
import java.util.LinkedHashMap;
import java.util.Map;

public final class q {
    static LinkedHashMap a;
    private static q b;
    private int c = 99;
    private String d = "1";
    private SharedPreferences e;

    static {
        b = null;
    }

    private q() {
    }

    public static Map a() {
        reference var2 = q.class;
        synchronized (q.class) {
            if (a == null) {
                a = new LinkedHashMap();
            }
            LinkedHashMap linkedHashMap = a;
            // ** MonitorExit[var2] (shouldn't be in output)
            return linkedHashMap;
        }
    }

    public static q c() {
        if (b == null) {
            b = new q();
        }
        return b;
    }

    public void a(SharedPreferences sharedPreferences) {
        this.e = sharedPreferences;
    }

    public SharedPreferences b() {
        return this.e;
    }
}

