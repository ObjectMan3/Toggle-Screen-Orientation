/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.os.Handler
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.DialogInterface;
import android.os.Handler;
import ui.robot.rotate.AppList;
import ui.robot.rotate.MyService;
import ui.robot.rotate.i;
import ui.robot.rotate.q;

class j
implements DialogInterface.OnClickListener {
    final /* synthetic */ i a;
    private final /* synthetic */ String b;
    private final /* synthetic */ CharSequence[] c;

    j(i i2, String string, CharSequence[] arrcharSequence) {
        this.a = i2;
        this.b = string;
        this.c = arrcharSequence;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onClick(DialogInterface dialogInterface, int n2) {
        if (n2 == 0) {
            q.a().remove((Object)this.b);
        } else if (n2 >= 1 && n2 <= 8) {
            q.a().put((Object)this.b, (Object)MyService.a(this.c[n2], AppList.b(i.a(this.a))));
        }
        i.a((i)this.a).f.sendEmptyMessage(1);
        dialogInterface.dismiss();
    }
}

