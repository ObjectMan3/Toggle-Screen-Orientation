/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.content.Context
 *  android.os.Handler
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Map
 */
package ui.robot.rotate;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Handler;
import java.util.Map;
import ui.robot.rotate.MyService;
import ui.robot.rotate.aa;
import ui.robot.rotate.z;

class r
implements Runnable {
    final /* synthetic */ MyService a;

    r(MyService myService) {
        this.a = myService;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void run() {
        try {
            String string = this.a.a(MyService.a(this.a));
            if (!this.a.h.equalsIgnoreCase(string)) {
                this.a.h = string;
                aa aa2 = this.a.a(this.a.b, string, MyService.a, "rotate");
                aa aa3 = this.a.f.c;
                if (aa2 == null) {
                    if (!this.a.i.equals((Object)aa3)) {
                        this.a.a(aa3, true);
                    }
                    this.a.i = aa3;
                } else {
                    if (!this.a.i.equals((Object)aa2)) {
                        this.a.a(aa2, true);
                    }
                    this.a.i = aa2;
                }
            }
            this.a.t.postDelayed((Runnable)this, 120);
            return;
        }
        catch (Exception var1_4) {
            return;
        }
    }
}

