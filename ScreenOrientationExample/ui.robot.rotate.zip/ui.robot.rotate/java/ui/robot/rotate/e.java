/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import ui.robot.rotate.AlertDialog;

class e
implements DialogInterface.OnClickListener {
    final /* synthetic */ AlertDialog a;

    e(AlertDialog alertDialog) {
        this.a = alertDialog;
    }

    public void onClick(DialogInterface dialogInterface, int n2) {
        Bundle bundle = new Bundle();
        bundle.putString("word", "cancel");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        this.a.setResult(-1, intent);
        this.a.finish();
    }
}

