/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningServiceInfo
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 */
package ui.robot.rotate;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import java.util.Iterator;
import java.util.List;
import ui.robot.rotate.AlertDialog2;
import ui.robot.rotate.z;

public class ServiceDialog
extends Activity {
    private static String g = "ui.robot.rotate";
    private static String h = "ui.robot.rotatedonate";
    z a = new z();
    private Context b;
    private boolean c = true;
    private SharedPreferences d;
    private AlertDialog.Builder e;
    private AlertDialog f;

    static /* synthetic */ SharedPreferences a(ServiceDialog serviceDialog) {
        return serviceDialog.d;
    }

    static boolean a(Context context, String string) {
        Iterator iterator = ((ActivityManager)context.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE).iterator();
        do {
            if (iterator.hasNext()) continue;
            return false;
        } while (!string.equals((Object)((ActivityManager.RunningServiceInfo)iterator.next()).service.getPackageName()));
        return true;
    }

    static /* synthetic */ Context b(ServiceDialog serviceDialog) {
        return serviceDialog.b;
    }

    void a() {
        if (ServiceDialog.a(this.b, h)) {
            this.startActivityForResult(new Intent((Context)this, (Class)AlertDialog2.class), 1);
            return;
        }
        this.b();
    }

    /*
     * Exception decompiling
     */
    void b() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    protected void onActivityResult(int n2, int n3, Intent intent) {
        Boolean bl;
        String string;
        super.onActivityResult(n2, n3, intent);
        if (n2 == 1 && n3 == -1 && (string = intent.getExtras().getString("word")) != null && string.equalsIgnoreCase("cancel")) {
            this.finish();
        }
        if (n2 == 2 && n3 == -1 && (bl = Boolean.valueOf((boolean)intent.getExtras().getBoolean("cur.enable"))) != null && !bl.booleanValue()) {
            this.finish();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.b = this.getApplicationContext();
    }

    protected void onPause() {
        try {
            super.onPause();
            this.f.dismiss();
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            this.a();
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }
}

