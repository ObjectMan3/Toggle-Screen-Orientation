/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

public class p {
    public static final String a = String.valueOf((Object)p.class.getName()) + "_intent";
}

