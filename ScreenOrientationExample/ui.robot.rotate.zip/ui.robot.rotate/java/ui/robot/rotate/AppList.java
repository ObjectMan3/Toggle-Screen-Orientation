/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.PackageManager
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.ListView
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package ui.robot.rotate;

import a.a.a.c;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import ui.robot.rotate.aa;
import ui.robot.rotate.h;
import ui.robot.rotate.i;
import ui.robot.rotate.k;
import ui.robot.rotate.l;
import ui.robot.rotate.q;

public class AppList
extends Activity {
    PackageManager a;
    List b = new ArrayList();
    List c = new ArrayList();
    ArrayAdapter d;
    List e;
    Handler f;
    ProgressDialog g;
    private ListView h;
    private boolean i = true;
    private Context j;

    public AppList() {
        this.f = new h(this);
    }

    static /* synthetic */ ListView a(AppList appList) {
        return appList.h;
    }

    static /* synthetic */ Context b(AppList appList) {
        return appList.j;
    }

    void a() {
        Map map = this.getApplicationContext().getSharedPreferences("perapp", 1).getAll();
        q.a().clear();
        Iterator iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            q.a().put((Object)((String)entry.getKey()), (Object)aa.valueOf((String)entry.getValue()));
        }
        return;
    }

    boolean a(String string) {
        Iterator iterator = this.e.iterator();
        do {
            if (iterator.hasNext()) continue;
            return false;
        } while (!((String)iterator.next()).equals((Object)string));
        return true;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            this.j = this.getApplicationContext();
            this.e = c.a(this.j);
            this.a = this.getPackageManager();
            this.setContentView(2130903041);
            this.h = (ListView)this.findViewById(2131230724);
            this.h.setFastScrollEnabled(true);
            this.registerForContextMenu((View)this.h);
            this.h.setOnItemClickListener((AdapterView.OnItemClickListener)new i((AppList)this));
            this.d = new k((AppList)this, (Context)this, 2130903040);
            return;
        }
        catch (Exception var2_2) {
            return;
        }
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();
        try {
            SharedPreferences.Editor editor = this.getApplicationContext().getSharedPreferences("perapp", 1).edit();
            editor.clear();
            q.c();
            Iterator iterator = q.a().keySet().iterator();
            do {
                if (!iterator.hasNext()) {
                    editor.commit();
                    return;
                }
                String string = (String)iterator.next();
                q.c();
                editor.putString(string, ((aa)((Object)q.a().get((Object)string))).toString());
            } while (true);
        }
        catch (Exception var1_4) {
            return;
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            this.a();
            new Thread((Runnable)new l(this)).start();
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }
}

