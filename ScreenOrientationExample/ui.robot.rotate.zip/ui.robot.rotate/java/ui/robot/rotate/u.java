/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.os.Bundle
 *  android.preference.PreferenceManager
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import ui.robot.rotate.MyService;
import ui.robot.rotate.aa;
import ui.robot.rotate.z;

class u
extends BroadcastReceiver {
    final /* synthetic */ MyService a;

    u(MyService myService) {
        this.a = myService;
    }

    public void onReceive(Context context, Intent intent) {
        String string = intent.getExtras().getString("isVisible");
        if (string != null) {
            if (string.equalsIgnoreCase("prefchanged")) {
                this.a.j();
            }
            if (string.equalsIgnoreCase("landscape")) {
                z z2 = new z();
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)MyService.a);
                MyService.a(sharedPreferences, z2, MyService.a);
                z2.c = aa.b;
                MyService.b(sharedPreferences, z2, MyService.a);
                this.a.j();
            }
            if (string.equalsIgnoreCase("portrait")) {
                z z3 = new z();
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)MyService.a);
                MyService.a(sharedPreferences, z3, MyService.a);
                z3.c = aa.c;
                MyService.b(sharedPreferences, z3, MyService.a);
                this.a.j();
            }
        }
    }
}

