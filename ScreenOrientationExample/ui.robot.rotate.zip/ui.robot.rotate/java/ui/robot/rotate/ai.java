/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 */
package ui.robot.rotate;

import android.os.Handler;
import android.widget.SeekBar;
import ui.robot.rotate.SettingActivity;
import ui.robot.rotate.z;

class ai
implements SeekBar.OnSeekBarChangeListener {
    final /* synthetic */ SettingActivity a;

    ai(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void onProgressChanged(SeekBar seekBar, int n2, boolean bl) {
        int n3 = n2 + 50;
        if (Math.abs((int)(SettingActivity.b(this.a) - n3)) > 10) {
            SettingActivity.a(this.a).a();
            this.a.f = n3;
            this.a.c.removeCallbacks(this.a.e);
            this.a.c.postDelayed(this.a.e, 100);
            this.a.a.b = n3;
            SettingActivity.a(this.a, n3);
        }
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        SettingActivity.a(this.a).a();
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}

