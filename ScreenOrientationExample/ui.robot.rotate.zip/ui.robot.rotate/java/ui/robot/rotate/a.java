/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.view.View;
import ui.robot.rotate.AboutActivity;

class a
implements View.OnClickListener {
    final /* synthetic */ AboutActivity a;

    a(AboutActivity aboutActivity) {
        this.a = aboutActivity;
    }

    public void onClick(View view) {
        this.a.finish();
    }
}

