/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.String
 *  java.util.List
 */
package ui.robot.rotate;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import java.util.List;
import ui.robot.rotate.f;
import ui.robot.rotate.g;

public class AlertDialog2
extends Activity {
    private static String c = "ui.robot.rotate";
    private static String d = "ui.robot.rotatedonate";
    AlertDialog.Builder a;
    private AlertDialog b;

    static /* synthetic */ String a() {
        return d;
    }

    static void a(String string, Context context) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts((String)"package", (String)string, (String)null));
        intent.addFlags(268435456);
        if (context.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
            context.startActivity(intent);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.a = new AlertDialog.Builder((Context)this);
        this.a.setIcon(2130837504).setTitle(2131034112).setMessage(2131034135).setPositiveButton((CharSequence)"Yes", (DialogInterface.OnClickListener)new f((AlertDialog2)this)).setNegativeButton((CharSequence)"Cancel", (DialogInterface.OnClickListener)new g((AlertDialog2)this));
        this.b = this.a.create();
        this.b.show();
    }

    protected void onPause() {
        try {
            super.onPause();
            this.b.dismiss();
            this.finish();
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }
}

