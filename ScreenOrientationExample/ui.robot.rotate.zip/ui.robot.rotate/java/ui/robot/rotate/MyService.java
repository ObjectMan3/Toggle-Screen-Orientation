/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningTaskInfo
 *  android.app.Notification
 *  android.app.PendingIntent
 *  android.app.Service
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.Vibrator
 *  android.provider.Settings
 *  android.provider.Settings$System
 *  android.util.Log
 *  android.view.OrientationEventListener
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package ui.robot.rotate;

import a.a.a.a;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Log;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import ui.robot.rotate.ServiceDialog;
import ui.robot.rotate.aa;
import ui.robot.rotate.ab;
import ui.robot.rotate.q;
import ui.robot.rotate.r;
import ui.robot.rotate.s;
import ui.robot.rotate.t;
import ui.robot.rotate.u;
import ui.robot.rotate.v;
import ui.robot.rotate.x;
import ui.robot.rotate.z;

public class MyService
extends Service {
    public static Context a;
    public static List c;
    static int r;
    private int A = 0;
    private int B = 2;
    private int C = 2;
    private int D = 2;
    private int E = 2;
    private boolean F = false;
    private OrientationEventListener G;
    private WindowManager H;
    private View I;
    private WindowManager.LayoutParams J;
    private CharSequence K;
    private ActivityManager L;
    private List M;
    private SharedPreferences N;
    private BroadcastReceiver O;
    Map b;
    protected Vibrator d;
    int e = 3000;
    z f = new z();
    protected aa g;
    public String h = "";
    aa i = aa.i;
    String j = "Mode: ";
    protected Runnable k;
    BroadcastReceiver l;
    View.OnClickListener m;
    int n;
    int o;
    int p;
    boolean q;
    Handler s;
    Handler t;
    protected int u;
    protected boolean v;
    String w;
    Handler x;
    Runnable y;
    private ab z;

    static {
        c = new ArrayList();
        r = 2;
    }

    public MyService() {
        this.k = new r(this);
        this.l = new s(this);
        this.m = new t(this);
        this.n = 776;
        this.o = 2005;
        this.p = 0;
        this.O = new u(this);
        this.s = new Handler();
        this.t = new Handler();
        this.u = 0;
        this.v = true;
        this.w = "";
        this.x = new Handler();
        this.y = new v(this);
    }

    static /* synthetic */ ActivityManager a(MyService myService) {
        return myService.L;
    }

    public static CharSequence a(aa aa2, Context context) {
        aa aa3 = aa.a;
        String string = null;
        if (aa3 == aa2) {
            string = context.getString(2131034116);
        }
        if (aa.b == aa2) {
            string = context.getString(2131034117);
        }
        if (aa.c == aa2) {
            string = context.getString(2131034118);
        }
        if (aa.d == aa2) {
            string = context.getString(2131034119);
        }
        if (aa.e == aa2) {
            string = context.getString(2131034120);
        }
        if (aa.f == aa2) {
            string = context.getString(2131034121);
        }
        if (aa.g == aa2) {
            string = context.getString(2131034122);
        }
        if (aa.h == aa2) {
            string = context.getString(2131034123);
        }
        if (aa.j == aa2) {
            string = context.getString(2131034124);
        }
        return string;
    }

    public static aa a(CharSequence charSequence, Context context) {
        aa aa2 = aa.a;
        if (context.getString(2131034116).equals((Object)charSequence)) {
            aa2 = aa.a;
        }
        if (context.getString(2131034117).equals((Object)charSequence)) {
            aa2 = aa.b;
        }
        if (context.getString(2131034118).equals((Object)charSequence)) {
            aa2 = aa.c;
        }
        if (context.getString(2131034119).equals((Object)charSequence)) {
            aa2 = aa.d;
        }
        if (context.getString(2131034120).equals((Object)charSequence)) {
            aa2 = aa.e;
        }
        if (context.getString(2131034121).equals((Object)charSequence)) {
            aa2 = aa.f;
        }
        if (context.getString(2131034122).equals((Object)charSequence)) {
            aa2 = aa.g;
        }
        if (context.getString(2131034123).equals((Object)charSequence)) {
            aa2 = aa.h;
        }
        if (context.getString(2131034124).equals((Object)charSequence)) {
            aa2 = aa.j;
        }
        return aa2;
    }

    public static void a(SharedPreferences sharedPreferences, z z2, Context context) {
        z2.c = MyService.a(sharedPreferences.getString("mode", context.getString(2131034116)), context);
        z2.b = sharedPreferences.getInt("size", 130);
        z2.a = sharedPreferences.getBoolean("enable", false);
        z2.e = sharedPreferences.getBoolean("Cmode", false);
        z2.d = sharedPreferences.getBoolean("Bmode", false);
        z2.f = sharedPreferences.getBoolean("Vmode", true);
        z2.g = sharedPreferences.getBoolean("Nmode", true);
        z2.i = sharedPreferences.getBoolean("lockmode", true);
        z2.h = sharedPreferences.getBoolean("perapp", false);
    }

    static /* synthetic */ void a(MyService myService, int n2) {
        myService.A = n2;
    }

    static /* synthetic */ OrientationEventListener b(MyService myService) {
        return myService.G;
    }

    static String b(int n2) {
        if (n2 == 2) {
            return "portrait";
        }
        if (n2 == 0) {
            return "LANDSCAPE";
        }
        if (n2 == 8) {
            return "REVERSE_LANDSCAPE";
        }
        if (n2 == 9) {
            return "REVERSE_PORTRAIT";
        }
        return "unknown";
    }

    public static void b(SharedPreferences sharedPreferences, z z2, Context context) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("mode", MyService.a(z2.c, context).toString());
        editor.putInt("size", z2.b);
        editor.putBoolean("enable", z2.a);
        editor.putBoolean("Cmode", z2.e);
        editor.putBoolean("Bmode", z2.d);
        editor.putBoolean("Vmode", z2.f);
        editor.putBoolean("Nmode", z2.g);
        editor.putBoolean("lockmode", z2.i);
        editor.putBoolean("perapp", z2.h);
        editor.commit();
    }

    static /* synthetic */ void b(MyService myService, int n2) {
        myService.C = n2;
    }

    static /* synthetic */ ab c(MyService myService) {
        return myService.z;
    }

    static /* synthetic */ void c(MyService myService, int n2) {
        myService.D = n2;
    }

    static /* synthetic */ int d(MyService myService) {
        return myService.A;
    }

    static /* synthetic */ void d(MyService myService, int n2) {
        myService.B = n2;
    }

    static /* synthetic */ int e(MyService myService) {
        return myService.E;
    }

    static /* synthetic */ int f(MyService myService) {
        return myService.C;
    }

    static /* synthetic */ int g(MyService myService) {
        return myService.B;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    int a(Intent intent) {
        try {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                String string = String.valueOf((Object)bundle.getString("id"));
                if (string.equalsIgnoreCase("update")) {
                    this.f.c = MyService.a(q.c().b().getString("mode", a.getString(2131034116)), a);
                    this.a(this.f.c, this.K);
                    this.a(this.f.c);
                }
                string.equalsIgnoreCase("present");
            }
            this.b = q.a();
            a.a();
            return 1;
        }
        catch (Exception var2_4) {
            return 1;
        }
    }

    public String a(ActivityManager activityManager) {
        return ((ActivityManager.RunningTaskInfo)activityManager.getRunningTasks((int)1).get((int)0)).topActivity.getPackageName();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public aa a(Map map, String string, Context context, String string2) {
        try {
            Iterator iterator = this.M.iterator();
            do {
                if (iterator.hasNext()) continue;
                return null;
            } while (!string.equalsIgnoreCase((String)iterator.next()));
            return aa.g;
        }
        catch (Exception var5_7) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a() {
        MyService.b(this.D);
        if (r == 2) {
            if (this.D == 2) {
                this.a(0);
            } else if (this.D == 0) {
                this.a(0);
            } else if (this.D == 8) {
                this.a(0);
            } else {
                this.a(2);
            }
            this.J.screenOrientation = this.D;
            this.f.j = this.J;
            if (this.F) {
                this.H.updateViewLayout(this.I, (ViewGroup.LayoutParams)this.J);
            } else {
                this.F = true;
                this.H.addView(this.I, (ViewGroup.LayoutParams)this.J);
            }
        }
        this.E = this.D;
    }

    public void a(int n2) {
        Settings.System.putInt((ContentResolver)this.getContentResolver(), (String)"user_rotation", (int)n2);
    }

    void a(aa aa2) {
        this.a(aa2, false);
    }

    void a(aa aa2, CharSequence charSequence) {
        String string = "";
        if (aa2 != null) {
            this.j = a.getString(2131034129);
            string = String.valueOf((Object)this.j) + " " + (Object)MyService.a(aa2, a);
        }
        Notification notification = new Notification(2130837527, (CharSequence)string, System.currentTimeMillis());
        notification.setLatestEventInfo((Context)this, charSequence, (CharSequence)string, PendingIntent.getActivity((Context)this, (int)0, (Intent)new Intent((Context)this, (Class)ServiceDialog.class), (int)2097152));
        this.startForeground(1, notification);
    }

    void a(aa aa2, boolean bl) {
        if (this.q != this.f.i) {
            this.c();
        }
        this.g = aa2;
        if (aa2 == aa.a) {
            this.a(false);
            this.D = this.f.j.screenOrientation;
            if (bl) {
                this.D = 2;
                this.a();
                return;
            }
            this.a();
            return;
        }
        if (aa2 == aa.b) {
            this.e();
            return;
        }
        if (aa2 == aa.c) {
            this.d();
            return;
        }
        if (aa2 == aa.d) {
            this.f();
            return;
        }
        if (aa2 == aa.e) {
            this.g();
            return;
        }
        if (aa2 == aa.f) {
            this.a(true);
            return;
        }
        if (aa2 == aa.g) {
            this.h();
            return;
        }
        this.i();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(boolean bl) {
        ContentResolver contentResolver = this.getContentResolver();
        int n2 = bl ? 1 : 0;
        Settings.System.putInt((ContentResolver)contentResolver, (String)"accelerometer_rotation", (int)n2);
    }

    void b() {
        try {
            Map map = this.getApplicationContext().getSharedPreferences("perapp", 1).getAll();
            q.a().clear();
            Iterator iterator = map.entrySet().iterator();
            do {
                if (!iterator.hasNext()) {
                    return;
                }
                Map.Entry entry = (Map.Entry)iterator.next();
                q.a().put((Object)((String)entry.getKey()), (Object)aa.valueOf((String)entry.getValue()));
            } while (true);
        }
        catch (Exception var1_4) {
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    void c() {
        if (this.f.i) {
            this.o = 2005;
            this.n = 8;
            this.n = 776;
        } else {
            this.o = 2006;
            this.n = 525064;
        }
        if (this.F) {
            this.H.removeView(this.I);
            this.F = true;
            this.J = new WindowManager.LayoutParams();
            this.J.width = 0;
            this.J.height = 0;
            this.J.flags = this.n;
            this.J.type = this.o;
            this.J.format = -1;
            this.J.gravity = 51;
            this.J.x = -5;
            this.J.y = -5;
            this.J.screenOrientation = 0;
            this.H.addView(this.I, (ViewGroup.LayoutParams)this.J);
            this.q = this.f.i;
        }
    }

    void d() {
        this.D = 2;
        if (r == 2) {
            this.a(false);
            this.a();
        }
    }

    void e() {
        this.D = 0;
        if (r == 2) {
            this.a(false);
            this.a();
        }
    }

    void f() {
        this.D = 9;
        if (r == 2) {
            this.a(false);
            this.a();
        }
    }

    void g() {
        this.D = 8;
        if (r == 2) {
            this.a(false);
            this.a();
        }
    }

    void h() {
        this.a(true);
        if (this.F) {
            this.H.removeView(this.I);
            this.F = false;
        }
    }

    void i() {
        if (this.F) {
            this.H.removeView(this.I);
            this.F = false;
        }
        this.a(false);
        this.a(0);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    boolean j() {
        try {
            z z2 = this.f;
            MyService.a(this.N, this.f, a);
            this.a(this.f.c, this.K);
            this.a(this.f.c);
            do {
                return false;
                break;
            } while (true);
        }
        catch (Exception var1_2) {
            return false;
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (configuration.orientation != 2) {
            // empty if block
        }
    }

    /*
     * Exception decompiling
     */
    public void onCreate() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public void onDestroy() {
        Log.d((String)"rotate", (String)"onDestroy");
        this.G.disable();
        if (this.O != null) {
            this.unregisterReceiver(this.O);
        }
        if (this.l != null) {
            this.unregisterReceiver(this.l);
        }
        this.a(aa.h);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public int onStartCommand(Intent intent, int n2, int n3) {
        try {
            new Thread((Runnable)new x((MyService)this, intent)).start();
            do {
                return 1;
                break;
            } while (true);
        }
        catch (Exception var4_4) {
            return 1;
        }
    }
}

