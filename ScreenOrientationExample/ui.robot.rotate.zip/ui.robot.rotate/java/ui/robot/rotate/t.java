/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.os.Vibrator
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.os.Vibrator;
import android.view.View;
import ui.robot.rotate.MyService;

class t
implements View.OnClickListener {
    final /* synthetic */ MyService a;

    t(MyService myService) {
        this.a = myService;
    }

    public void onClick(View view) {
        MyService.c(this.a).a();
        this.a.d.vibrate(30);
        this.a.a(false);
        this.a.a();
    }
}

