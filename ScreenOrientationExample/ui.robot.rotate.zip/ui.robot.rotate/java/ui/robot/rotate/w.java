/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.io.PrintWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Object
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 */
package ui.robot.rotate;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import ui.robot.rotate.MyService;

class w
implements Thread.UncaughtExceptionHandler {
    final /* synthetic */ MyService a;

    w(MyService myService) {
        this.a = myService;
    }

    public void uncaughtException(Thread thread, Throwable throwable) {
        PrintWriter printWriter = new PrintWriter((Writer)new StringWriter());
        throwable.printStackTrace(printWriter);
        printWriter.close();
    }
}

