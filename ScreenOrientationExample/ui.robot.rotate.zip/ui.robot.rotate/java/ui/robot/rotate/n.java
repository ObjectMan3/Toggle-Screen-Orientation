/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Comparator
 */
package ui.robot.rotate;

import java.util.Comparator;
import ui.robot.rotate.aa;
import ui.robot.rotate.l;
import ui.robot.rotate.o;

class n
implements Comparator {
    final /* synthetic */ l a;

    n(l l2) {
        this.a = l2;
    }

    /*
     * Enabled aggressive block sorting
     */
    public int a(o o2, o o3) {
        String string;
        String string2 = o2.e == null ? "" : o2.e.toString().toLowerCase();
        if (o3.e == null) {
            string = "";
            return string.compareTo(string2);
        }
        string = o3.e.toString().toLowerCase();
        return string.compareTo(string2);
    }

    public /* synthetic */ int compare(Object object, Object object2) {
        return this.a((o)object, (o)object2);
    }
}

