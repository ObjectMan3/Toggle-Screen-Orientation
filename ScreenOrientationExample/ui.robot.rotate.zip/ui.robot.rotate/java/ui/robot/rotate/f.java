/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 */
package ui.robot.rotate;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import ui.robot.rotate.AlertDialog2;

class f
implements DialogInterface.OnClickListener {
    final /* synthetic */ AlertDialog2 a;

    f(AlertDialog2 alertDialog2) {
        this.a = alertDialog2;
    }

    public void onClick(DialogInterface dialogInterface, int n2) {
        AlertDialog2.a(AlertDialog2.a(), (Context)this.a);
        Bundle bundle = new Bundle();
        bundle.putString("word", "check");
        Intent intent = new Intent();
        intent.putExtras(bundle);
        this.a.setResult(-1, intent);
        this.a.finish();
    }
}

