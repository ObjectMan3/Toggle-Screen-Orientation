/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 */
package ui.robot.rotate;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import ui.robot.rotate.AppList;
import ui.robot.rotate.SettingActivity;

class ao
implements View.OnClickListener {
    final /* synthetic */ SettingActivity a;

    ao(SettingActivity settingActivity) {
        this.a = settingActivity;
    }

    public void onClick(View view) {
        try {
            Intent intent = new Intent((Context)this.a, (Class)AppList.class);
            this.a.startActivity(intent);
            return;
        }
        catch (Exception var3_3) {
            return;
        }
    }
}

