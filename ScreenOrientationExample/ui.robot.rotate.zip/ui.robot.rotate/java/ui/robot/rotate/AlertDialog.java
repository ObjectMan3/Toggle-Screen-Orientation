/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.CharSequence
 *  java.lang.String
 *  java.util.List
 */
package ui.robot.rotate;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import java.util.List;
import ui.robot.rotate.d;
import ui.robot.rotate.e;

public class AlertDialog
extends Activity {
    private static String a = "ui.robot.rotate";

    static /* synthetic */ String a() {
        return a;
    }

    static void a(String string, Context context) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts((String)"package", (String)string, (String)null));
        intent.addFlags(268435456);
        if (context.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
            context.startActivity(intent);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        builder.setIcon(2130837504).setTitle(2131034112).setMessage(2131034134).setPositiveButton((CharSequence)"Yes", (DialogInterface.OnClickListener)new d((AlertDialog)this)).setNegativeButton((CharSequence)"Cancel", (DialogInterface.OnClickListener)new e((AlertDialog)this)).create();
        builder.show();
    }
}

