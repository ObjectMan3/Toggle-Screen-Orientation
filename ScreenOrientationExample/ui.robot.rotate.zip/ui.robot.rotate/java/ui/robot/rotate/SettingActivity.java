/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.os.Bundle
 *  android.os.Handler
 *  android.preference.PreferenceManager
 *  android.util.Log
 *  android.view.KeyEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  android.widget.ToggleButton
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package ui.robot.rotate;

import a.a.a.b;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.ToggleButton;
import ui.robot.rotate.MyService;
import ui.robot.rotate.ab;
import ui.robot.rotate.ag;
import ui.robot.rotate.ah;
import ui.robot.rotate.ai;
import ui.robot.rotate.aj;
import ui.robot.rotate.ak;
import ui.robot.rotate.al;
import ui.robot.rotate.am;
import ui.robot.rotate.an;
import ui.robot.rotate.ao;
import ui.robot.rotate.p;
import ui.robot.rotate.q;
import ui.robot.rotate.z;

public class SettingActivity
extends Activity {
    z a = new z();
    Handler b = new Handler();
    Handler c = new Handler();
    protected Runnable d;
    protected Runnable e;
    protected int f;
    private Context g;
    private ToggleButton h;
    private ToggleButton i;
    private ToggleButton j;
    private ToggleButton k;
    private int l;
    private SharedPreferences m;
    private ToggleButton n;
    private SeekBar o;
    private ab p;
    private WindowManager q;
    private boolean r;
    private ToggleButton s;
    private int t;

    public SettingActivity() {
        this.d = new ag(this);
        this.e = new ah(this);
        this.r = false;
        this.t = 0;
    }

    static /* synthetic */ ab a(SettingActivity settingActivity) {
        return settingActivity.p;
    }

    private void a(SeekBar seekBar) {
        try {
            seekBar.setMax(190);
            seekBar.setProgress(-50 + this.a.b);
            seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener)new ai((SettingActivity)this));
            return;
        }
        catch (Exception var2_2) {
            return;
        }
    }

    static /* synthetic */ void a(SettingActivity settingActivity, int n2) {
        settingActivity.t = n2;
    }

    static /* synthetic */ int b(SettingActivity settingActivity) {
        return settingActivity.t;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        try {
            int n2 = keyEvent.getKeyCode();
            if (keyEvent.getAction() == 1 && n2 == 4) {
                if (this.l != 1) return true;
                {
                    Log.i((String)"rotate", (String)("at (" + b.a(this) + b.a() + ")" + "[" + this.a.a + "]"));
                    MyService.b(this.m, this.a, this.g);
                    if (this.a.a) {
                        Intent intent = new Intent((Context)this, (Class)MyService.class);
                        intent.putExtra("id", "start");
                        this.startService(intent);
                        Intent intent2 = new Intent();
                        intent2.setAction(p.a);
                        intent2.putExtra("isVisible", "prefchanged");
                        this.g.sendBroadcast(intent2);
                    } else {
                        this.stopService(new Intent((Context)this, (Class)MyService.class));
                    }
                    Bundle bundle = new Bundle();
                    bundle.putBoolean("cur.enable", this.a.a);
                    Intent intent = new Intent();
                    intent.putExtras(bundle);
                    this.setResult(-1, intent);
                    this.finish();
                    return true;
                }
            }
            if (keyEvent.getAction() != 0 || n2 != 4) return super.dispatchKeyEvent(keyEvent);
            Log.i((String)"rotate", (String)("at (" + b.a(this) + b.a() + ")" + "[" + this.a.a + "]"));
            this.l = 1;
            return true;
        }
        catch (Exception var2_7) {
            return super.dispatchKeyEvent(keyEvent);
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            this.g = this.getApplicationContext();
            this.getPreferences(0);
            q.c().a(PreferenceManager.getDefaultSharedPreferences((Context)this));
            this.m = PreferenceManager.getDefaultSharedPreferences((Context)this.g);
            MyService.a(this.m, this.a, this.g);
            this.a.a = true;
            this.p = new ab(this.g);
            this.q = (WindowManager)this.getSystemService("window");
            if (!this.r) {
                this.q.addView((View)this.p, (ViewGroup.LayoutParams)new WindowManager.LayoutParams(2003, 8));
            }
            this.r = true;
            this.setContentView(2130903042);
            this.o = (SeekBar)this.findViewById(2131230732);
            this.o.setEnabled(false);
            super.a(this.o);
            this.h = (ToggleButton)this.findViewById(2131230726);
            this.h.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new aj((SettingActivity)this));
            this.i = (ToggleButton)this.findViewById(2131230731);
            this.i.setEnabled(false);
            this.i.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new ak((SettingActivity)this));
            this.j = (ToggleButton)this.findViewById(2131230728);
            this.j.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new al((SettingActivity)this));
            this.k = (ToggleButton)this.findViewById(2131230730);
            this.k.setEnabled(false);
            this.s = (ToggleButton)this.findViewById(2131230727);
            this.s.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new am((SettingActivity)this));
            this.n = (ToggleButton)this.findViewById(2131230733);
            this.n.setEnabled(false);
            this.n.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new an((SettingActivity)this));
            Button button = (Button)this.findViewById(2131230729);
            button.setEnabled(false);
            button.setOnClickListener((View.OnClickListener)new ao((SettingActivity)this));
            this.h.setChecked(this.a.a);
            this.i.setChecked(this.a.g);
            this.k.setChecked(this.a.h);
            this.j.setChecked(this.a.i);
            this.s.setChecked(this.a.d);
            this.n.setChecked(this.a.f);
            return;
        }
        catch (Exception var2_3) {
            return;
        }
    }

    protected void onDestroy() {
        try {
            super.onDestroy();
            if (this.r) {
                this.q.removeView((View)this.p);
                this.r = false;
            }
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }

    protected void onPause() {
        super.onPause();
        try {
            if (this.r) {
                this.q.removeView((View)this.p);
                this.r = false;
            }
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (!this.r) {
                this.q.addView((View)this.p, (ViewGroup.LayoutParams)new WindowManager.LayoutParams(2003, 8));
                this.r = true;
            }
            return;
        }
        catch (Exception var1_1) {
            return;
        }
    }
}

